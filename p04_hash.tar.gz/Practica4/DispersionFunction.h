#ifndef DISPERSIONFUNCTION_H
#define DISPERSIONFUNCTION_H

#include "includes.h"

// Clase Abstracta
template <typename Key>
class DispersionFunction {
public:
  virtual unsigned operator()(const Key &) const = 0;
  virtual ~DispersionFunction() {}
};

// Clase Dispersión % (Módulo)
template <typename Key>
class ModuloDispersion : public DispersionFunction<Key> {
public:
  ModuloDispersion(unsigned size);
  unsigned operator()(const Key &k) const override;
  
private:
  unsigned tableSize_;
};

// Implementación de ModuloDispersion
template <typename Key>
ModuloDispersion<Key>::ModuloDispersion(unsigned size) : tableSize_(size) {}

template <typename Key>
unsigned ModuloDispersion<Key>::operator()(const Key &k) const {
  return k % tableSize_;
}

// Clase Dispersión + (Suma de dígitos)
template <typename Key>
class SumDispersion : public DispersionFunction<Key> {
public:
  SumDispersion(unsigned size);
  unsigned operator()(const Key &k) const override;
  
private:
  unsigned tableSize_;
};

// Implementación de SumDispersion
template <typename Key>
SumDispersion<Key>::SumDispersion(unsigned size) : tableSize_(size) {}

template <typename Key>
unsigned SumDispersion<Key>::operator()(const Key &k) const {
  unsigned sum = 0;
  unsigned value = k;
  while (value > 0) {
    sum += value % 10;
    value /= 10;
  }
  return sum % tableSize_;
}

// Clase Dispersión rand() (Pseudorandom)
template <typename Key>
class PseudoRandomDispersion : public DispersionFunction<Key> {
public:
  PseudoRandomDispersion(unsigned size);
  unsigned operator()(const Key &k) const override;
  
private:
  unsigned tableSize_;
};

// Implementación de PseudoRandomDispersion
template <typename Key>
PseudoRandomDispersion<Key>::PseudoRandomDispersion(unsigned size) : tableSize_(size) {}

template <typename Key>
unsigned PseudoRandomDispersion<Key>::operator()(const Key &k) const {
  srand(k);
  return rand() % tableSize_;
}

#endif
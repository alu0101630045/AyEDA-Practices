#ifndef HASHTABLE_H
#define HASHTABLE_H

#include "DispersionFunction.h"
#include "ExplorationFunction.h"
#include "Sequence.h"
#include "includes.h"

// Clase para la tabla Hash estática
template <class Key, class Container = staticSequence<Key>>
class HashTable : public Sequence<Key> {
public:
  HashTable(unsigned size, DispersionFunction<Key> &dispersion, ExplorationFunction<Key> &exploration, unsigned block = 0);
  ~HashTable();
  bool search(const Key &k) const override;
  bool insert(const Key &k) override;
  bool isFull() const;
  Key GetKey(const Key &k) const;
  long GetIndex(const Key &k) const;
  void print() override;
private:
  unsigned tableSize;
  Container **table;
  DispersionFunction<Key> &fd;
  ExplorationFunction<Key> &fe;
  unsigned blockSize;
};

// Implementación de la tabla Hash estática
template <class Key, class Container>
HashTable<Key, Container>::HashTable(unsigned size, DispersionFunction<Key> &dispersion, ExplorationFunction<Key> &exploration, unsigned block)
  : tableSize(size), fd(dispersion), fe(exploration), blockSize(block) {
  table = new Container *[tableSize];
  for (unsigned i = 0; i < tableSize; ++i) {
    table[i] = new Container(blockSize);
  }
}

template <class Key, class Container>
HashTable<Key, Container>::~HashTable() {
  for (unsigned i = 0; i < tableSize; ++i) {
    delete table[i];
  }
  delete[] table;
}

template <class Key, class Container>
bool HashTable<Key, Container>::search(const Key &k) const {
  unsigned index = fd(k) % tableSize;  // Índice inicial
  unsigned i = 0;

  while (table[index] != nullptr) {  // Mientras la celda no esté vacía
    if (table[index]->search(k)) {  // Si la clave está en la celda
      std::cout << "Search in table: Found at Index: " << index << std::endl;
      return true;
    }
    i++;  
    index = (fd(k) + fe(k, i)) % tableSize;  
    if (i == tableSize) {  
      break;
    }
  }
  std::cout << "Search in table: Not found" << std::endl;
  return false;
}


template <class Key, class Container>
bool HashTable<Key, Container>::insert(const Key &k) {
  unsigned index = fd(k) % tableSize; 
  unsigned i = 0;  
  while (!table[index]->insert(k)) {  
    i++;  
    index = (fd(k) + fe(k, i)) % tableSize; 
    if (i == tableSize) {
      std::cerr << "Error: La tabla está llena, no se pudo insertar el valor.\n";
      return false;
    }
  }
  return true; 
}

template <class Key, class Container>
bool HashTable<Key, Container>::isFull() const {
  for (unsigned i = 0; i < tableSize; ++i) {
    if (!table[i]->isFull())
      return false;
  }
  return true;
}

template <class Key, class Container>
Key HashTable<Key, Container>::GetKey(const Key &k) const {
  return k;
}

template <class Key, class Container>
long HashTable<Key, Container>::GetIndex(const Key &k) const {
  for (unsigned i = 0; i < tableSize; ++i) {
    if (table[i]->search(k))
      return i;
  }
  return -1;
}

template <class Key, class Container>
void HashTable<Key, Container>::print() {
  for (unsigned i = 0; i < tableSize; ++i) {
    std::cout << "Table[" << i << "]: ";
    table[i]->print();
  }
}

// Clase para tabla Hash dinámica (especialización)
template <class Key>
class HashTable<Key, dynamicSequence<Key>> : public Sequence<Key> {
public:
  HashTable(unsigned size, DispersionFunction<Key> &dispersion);
  ~HashTable();
  bool search(const Key &k) const override;
  bool insert(const Key &k) override;
  Key GetKey(const Key &k) const;
  long GetIndex(const Key &k) const;
  void print() override;
private:
  unsigned tableSize;
  dynamicSequence<Key> **table;
  DispersionFunction<Key> &fd;
};

// Implementación de la tabla Hash dinámica
template <class Key>
HashTable<Key, dynamicSequence<Key>>::HashTable(unsigned size, DispersionFunction<Key> &dispersion)
    : tableSize(size), fd(dispersion) {
  table = new dynamicSequence<Key> *[tableSize];
  for (unsigned i = 0; i < tableSize; ++i) {
    table[i] = new dynamicSequence<Key>;
  }
}

template <class Key>
HashTable<Key, dynamicSequence<Key>>::~HashTable() {
  for (unsigned i = 0; i < tableSize; ++i) {
    delete table[i];
  }
  delete[] table;
}

template <class Key>
bool HashTable<Key, dynamicSequence<Key>>::search(const Key &k) const {
  unsigned index = fd(k) % tableSize;
  return table[index]->search(k);
}

template <class Key>
bool HashTable<Key, dynamicSequence<Key>>::insert(const Key &k) {
  unsigned index = fd(k) % tableSize;
  return table[index]->insert(k);
}

template <class Key>
Key HashTable<Key, dynamicSequence<Key>>::GetKey(const Key &k) const {
  return k;
}

template <class Key>
long HashTable<Key, dynamicSequence<Key>>::GetIndex(const Key &k) const {
  return fd(k) % tableSize;
}

template <class Key>
void HashTable<Key, dynamicSequence<Key>>::print() {
  for (unsigned i = 0; i < tableSize; ++i) {
    std::cout << "Table[" << i << "]: ";
    table[i]->print();
  }
}

#endif

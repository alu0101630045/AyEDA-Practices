#ifndef EXPLORATIONFUNCTION_H
#define EXPLORATIONFUNCTION_H

#include "includes.h"
#include "DispersionFunction.h"



// Clase abstracta
template <typename Key>
class ExplorationFunction {
public:
  virtual unsigned operator()(const Key &, unsigned) const = 0;
  virtual ~ExplorationFunction() {}
};



// Clase exploración lineal
template <typename Key>
class LinearExploration : public ExplorationFunction<Key> {
public:
  virtual unsigned operator()(const Key &, unsigned i) const override { return i; }
};



// Clase exploración cuadrática
template <typename Key>
class QuadraticExploration : public ExplorationFunction<Key> {
public:
  virtual unsigned operator()(const Key &, unsigned i) const override {
    return i * i;
  }
};



// Clase exploración hash doble
template <typename Key>
class DoubleHashExploration : public ExplorationFunction<Key> {
public:
  DoubleHashExploration(DispersionFunction<Key> *dispersion) : f_(dispersion) {}
  virtual unsigned operator()(const Key &k, unsigned i) const override { return (*f_)(k) * i; }
private:
  DispersionFunction<Key> *f_;
};



// Clase exploración rehashing
template <typename Key>
class RehashingExploration : public ExplorationFunction<Key> {
public:
  RehashingExploration(DispersionFunction<Key> *dispersion);
  unsigned operator()(const Key &k, unsigned i) const override;

private:
  DispersionFunction<Key> *f_;
};

// Implementación de RehashingExploration
template <typename Key>
RehashingExploration<Key>::RehashingExploration(DispersionFunction<Key> *dispersion) : f_(dispersion) {}

template <typename Key>
unsigned RehashingExploration<Key>::operator()(const Key &k, unsigned i) const {
  srand(k);
  unsigned desplazamiento = 0;
  for (unsigned j = 0; j <= i; ++j) {
    desplazamiento = rand();
  }
  return desplazamiento;
}

#endif


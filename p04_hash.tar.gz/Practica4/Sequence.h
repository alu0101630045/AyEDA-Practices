#ifndef __SEQUENCE_H__
#define __SEQUENCE_H__

#include "includes.h"

// Abstract base class for sequences
template <class Key>
class Sequence {
public:
  virtual bool search(const Key &k) const = 0;
  virtual bool insert(const Key &k) = 0;
  virtual ~Sequence() {}
  virtual void print() = 0;
};

// Dynamic sequence for open addressing
template <class Key>
class dynamicSequence : public Sequence<Key> {
public:
  bool search(const Key &k) const override;
  bool insert(const Key &k) override;
  void print() override;

private:
  std::vector<Key> data;
};

// Static sequence for closed addressing
template <class Key>
class staticSequence : public Sequence<Key> {
public:
  staticSequence(unsigned size);
  bool search(const Key &k) const override;
  bool insert(const Key &k) override;
  bool isFull() const;
  void print() override;

private:
  std::vector<Key> data;
  unsigned blockSize;
};

// Implementación de dynamicSequence
template <class Key>
bool dynamicSequence<Key>::search(const Key &k) const {
  for (const auto &key : data) {
    if (key == k) {
      return true;
    }
  }
  return false;
}

template <class Key>
bool dynamicSequence<Key>::insert(const Key &k) {
  if (!search(k)) {
    data.push_back(k);
    return true;
  }
  return false;
}

template <class Key>
void dynamicSequence<Key>::print() {
  for (const auto &key : data) {
    std::cout << key << " ";
  }
  std::cout << std::endl;
}

// Implementación de staticSequence
template <class Key>
staticSequence<Key>::staticSequence(unsigned size) : blockSize(size) {
  data.reserve(blockSize);
}

template <class Key>
bool staticSequence<Key>::search(const Key &k) const {
  for (const auto &key : data) {
    if (key == k) {
      return true;
    }
  }
  return false;
}

template <class Key>
bool staticSequence<Key>::insert(const Key &k) {
  if (data.size() < blockSize && !search(k)) {
    data.push_back(k);
    return true;
  }
  return false;
}

template <class Key>
bool staticSequence<Key>::isFull() const {
  return data.size() >= blockSize;
}

template <class Key>
void staticSequence<Key>::print() {
  for (const auto &key : data) {
    std::cout << key << " ";
  }
  std::cout << std::endl;
}

#endif
#ifndef INCLUDES_H
#define INCLUDES_H

#include <cstdlib>
#include <ctime>
#include <iostream>
#include <optional>
#include <vector>
#include <string>
#include <fstream>

#endif 

#include "NIF.h"
#include "functions.h"

// MODIFICACIÓN
// Clase PERSONA con atributo NIF, Nombre, Edad (int)
// La Clave seguirá siendo el NIF

int main(int argc, char const *argv[]) {
  // Pruebas();
  auto options = parse_args(argc, argv);
  if (!options) {
    Usage();
    return 1;
  }
  // Declaramos los punteros a las funciones de dispersión y exploración
  DispersionFunction<NIF> *dispersion;
  ExplorationFunction<NIF> *exploration;
  // Inicializamos las funciones de dispersión y exploración
  initializeFunctions(*options, dispersion, exploration);
  // Creamos la tabla hash
  unsigned tableSize = options->tableSize;
  unsigned blockSize = options->blockSize;
  if (options->hashType == "open") {
    HashTable<NIF, dynamicSequence<NIF>> table(tableSize, *dispersion);
    // Añadir valores random a la tabla
    for (unsigned i = 0; i < tableSize; ++i) {
      table.insert(NIF());
    }
    Menu(&table);
  }
  else if (options->hashType == "close") {
    HashTable<NIF, staticSequence<NIF>> table(tableSize, *dispersion, *exploration, blockSize);
    // Añadir valores random a la tabla
    for (unsigned i = 0; i < tableSize; ++i) {
      // Crear NIF
      NIF nif;
      table.insert(nif);
    }
    Menu(&table);
  }
  else {
    Usage();
    return 1;
  }
  // std::cout << "Number of compare and swap operations: " << compare_swapkeys_count << std::endl;
  return 0;
}

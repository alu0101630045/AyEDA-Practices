#include "Persona.h"
#include "functions.h"

// MODIFICACIÓN
// Clase PERSONA con atributo NIF, Nombre, Edad (int)
// La Clave seguirá siendo el NIF
Persona Juan(11111111, "Juan", 20);
Persona Ana(22222222, "Ana", 25);

int main(int argc, char const *argv[]) {
  // Pruebas();
  auto options = parse_args(argc, argv);
  if (!options) {
    Usage();
    return 1;
  }
  // Declaramos los punteros a las funciones de dispersión y exploración
  DispersionFunction<Persona> *dispersion;
  ExplorationFunction<Persona> *exploration;
  // Inicializamos las funciones de dispersión y exploración
  initializeFunctions(*options, dispersion, exploration);
  // Creamos la tabla hash
  unsigned tableSize = options->tableSize;
  unsigned blockSize = options->blockSize;
  if (options->hashType == "open") {
    HashTable<Persona, dynamicSequence<Persona>> table(tableSize, *dispersion);
    table.insert(Juan);
    table.insert(Ana);
    Menu(&table);
  }
  else if (options->hashType == "close") {
    HashTable<Persona, staticSequence<Persona>> table(tableSize, *dispersion, *exploration, blockSize);
    table.insert(Juan);
    table.insert(Ana);
    Menu(&table);
  }
  else {
    Usage();
    return 1;
  }
  // std::cout << "Number of compare and swap operations: " << compare_swapkeys_count << std::endl;
  return 0;
}

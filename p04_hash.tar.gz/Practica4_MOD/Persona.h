#include "includes.h"
#include "NIF.h"

class Persona {
  public:
  Persona();
  Persona(NIF dni, std::string name, int age);
  NIF getDni() const { return dni_; }
  std::string getName() const { return name_; }
  int getAge() const { return age_; }
  friend std::ostream &operator<<(std::ostream &os, const Persona &p);
  friend std::istream &operator>>(std::istream &is, Persona &p);
  operator long() const { return dni_.getValue(); }

  private:
    NIF dni_;
    std::string name_;
    int age_;
};

Persona::Persona() : dni_(), name_(""), age_(0) {}

Persona::Persona(NIF dni, std::string name, int age) : dni_(dni), name_(name), age_(age) {}

std::ostream &operator<<(std::ostream &os, const Persona &p) {
  os << "DNI: " << p.dni_ << " Name: " << p.name_ << " Age: " << p.age_;
  return os;
}

std::istream &operator>>(std::istream &is, Persona &p) {
  is >> p.dni_;
  std::cout << "Introduzca el nombre completo: ";
  is >> p.name_;
  std::cout << "Introduzca la edad: ";
  is >> p.age_;
  return is;
}
// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Algortimos y Estructuras de Datos Avanzadas
// Curso: 2º
// Práctica 6: Implementación de TDA
// Autor: Pablo García de los Reyes
// Correo: alu0101630045@ull.edu.es
// Fecha: 30/04/2025
// Archivo main.cc: Archivo principal del programa
// Contiene la declaración de la función main

#include <iostream>
#include "Funciones.h"

int main(int argc, char* argv[]) {
  configurarEIniciarPrograma(argc, argv);
  return 0;
}

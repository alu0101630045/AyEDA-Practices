// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Algortimos y Estructuras de Datos Avanzadas
// Curso: 2º
// Práctica 6: Implementación de TDA
// Autor: Pablo García de los Reyes
// Correo: alu0101630045@ull.edu.es
// Fecha: 30/04/2025
// Archivo NodoAVL.h: Archivo de cabecera de la clase NodoAVL
// Contiene la declaración de la clase NodoAVL para su uso en los AVL

#ifndef __NODOAVL_H__
#define __NODOAVL_H__

#include "NodoB.h"

template <class Key>
class NodoAVL : public NodoB<Key> {
public:
  NodoAVL(Key dato, NodoAVL<Key>* iz = nullptr, NodoAVL<Key>* der = nullptr)
  : NodoB<Key>(dato), dato_(dato), bal_(0), izquierdo(iz), derecho(der) {}
  ~NodoAVL() {}

  NodoAVL<Key> *izquierdo;
  NodoAVL<Key> *derecho;

  int getBal() const { return bal_; }
  void setBal(int bal) { bal_ = bal; }

  Key getData() const { return dato_; }

private:
  Key dato_;
  int bal_;
};

#endif // __NODOAVL_H__
// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Algortimos y Estructuras de Datos Avanzadas
// Curso: 2º
// Práctica 6: Implementación de TDA
// Autor: Pablo García de los Reyes
// Correo: alu0101630045@ull.edu.es
// Fecha: 30/04/2025
// Archivo NIF.h: Archivo de cabecera de la clase NIF
// Contiene la declaración de la clase NIF para su uso como clave en los árboles binarios.

#ifndef NIF_H
#define NIF_H

#include "includes.h"

class NIF {
public:
  NIF();
  NIF(long val);
  bool operator==(const NIF &other) const;
  bool operator!=(const NIF &other) const;
  operator long() const;
  long getValue() const;
  friend std::istream &operator>>(std::istream &is, NIF &nif);
  friend std::ostream &operator<<(std::ostream &os, const NIF &nif);
private:
  long value_;
};

NIF::NIF() : value_(10000000 + rand() % 90000000) {}  // Genera siempre un número de 8 cifras

NIF::NIF(long val) : value_(val) {}

bool NIF::operator==(const NIF &other) const {
  return value_ == other.value_;
}

bool NIF::operator!=(const NIF &other) const {
  return !(value_ == other.value_);
}

NIF::operator long() const {
  return value_;
}

long NIF::getValue() const {
  return value_;
}

std::istream &operator>>(std::istream &is, NIF &nif) {
  is >> nif.value_;
  // Comprobar si el NIF tiene exactamente 8 dígitos (comentado para poder usar números más pequeños en los tests presenciales con el profesor)
  // while (nif.value_ < 10000000 || nif.value_ > 99999999) {
  //   std::cerr << "Error: NIF must have 8 digits. Try again: ";
  //   is >> nif.value_;
  // }
  return is;
}

std::ostream &operator<<(std::ostream &os, const NIF &nif) {
  os << nif.value_;
  return os;
}

#endif

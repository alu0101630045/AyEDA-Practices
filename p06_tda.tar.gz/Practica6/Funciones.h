// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Algortimos y Estructuras de Datos Avanzadas
// Curso: 2º
// Práctica 6: Implementación de TDA
// Autor: Pablo García de los Reyes
// Correo: alu0101630045@ull.edu.es
// Fecha: 30/04/2025
// Archivo Funciones.h: Declaración de funciones necesarias para la interfaz de usuario
// Contiene la declaración y definición del menú para el usuario y sus respectivas funcionalidades

#ifndef FUNCIONES_H
#define FUNCIONES_H

#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <ctime>

#include "AB.h"
#include "ABB.h"
#include "AVL.h"
#include "NIF.h"

// Muestra el menú al usuario
void mostrarMenu() {
  std::cout << "\nMenú de opciones:\n";
  std::cout << "[0] Salir\n";
  std::cout << "[1] Insertar clave\n";
  std::cout << "[2] Buscar clave\n";
  std::cout << "[3] Mostrar árbol inorden\n";
  std::cout << "Elija una opción: ";
}

// Inicializa el árbol desde archivo
template <typename T>
void inicializarArbolDesdeArchivo(AB<T>* arbol, const std::string& nombreFichero) {
  std::ifstream archivo(nombreFichero);
  if (!archivo.is_open()) {
    std::cerr << "No se pudo abrir el archivo: " << nombreFichero << "\n";
    return;
  }

  T valor;
  int contador = 0;
  while (archivo >> valor) {
    if (arbol->insertar(valor)) {
      contador++;
    }
  }

  archivo.close();
  std::cout << "Árbol inicializado con " << contador << " elementos desde archivo.\n";
  arbol->visualizar();
}

// Inicializa el árbol de forma aleatoria
template <typename T>
void inicializarArbolAleatorio(AB<T>* arbol, int cantidad) {
  std::srand(std::time(0));
  for (int i = 0; i < cantidad; ++i) {
    T valor = std::rand() % 100000000 + 1;
    arbol->insertar(valor);
  }

  std::cout << "Árbol inicializado con " << cantidad << " elementos aleatorios.\n";
  arbol->visualizar();
}

// Procesa argumentos, crea árbol e inicia menú
void configurarEIniciarPrograma(int argc, char* argv[]) {
  std::string tipoArbol = "abb";
  std::string inicializacion = "manual";
  bool mostrarTraza = false;
  int cantidadElementos = 0;
  std::string nombreFichero;

  // Procesar argumentos
  for (int i = 1; i < argc; ++i) {
    std::string arg = argv[i];
    if (arg == "-ab") {
      tipoArbol = argv[++i];
    } else if (arg == "-init") {
      inicializacion = argv[++i];
      if (inicializacion == "random") {
        cantidadElementos = std::stoi(argv[++i]);
      } else if (inicializacion == "file") {
        nombreFichero = argv[++i];
      }
    } else if (arg == "-trace") {
      mostrarTraza = (std::string(argv[++i]) == "y");
    }
  }

  // Crear árbol
  AB<NIF>* arbol = nullptr;
  if (tipoArbol == "abb") {
    arbol = new ABB<NIF>();
    std::cout << "Árbol ABB creado.\n";
  } else if (tipoArbol == "avl") {
    arbol = new AVL<NIF>(mostrarTraza);
    std::cout << "Árbol AVL creado.\n";
  } else {
    std::cerr << "Tipo de árbol no reconocido. Usa 'abb' o 'avl'.\n";
    return;
  }

  // Inicialización del árbol
  if (inicializacion == "manual") {
    std::cout << "Inicialización manual. Árbol vacío.\n";
  } else if (inicializacion == "random") {
    inicializarArbolAleatorio(arbol, cantidadElementos);
  } else if (inicializacion == "file") {
    inicializarArbolDesdeArchivo(arbol, nombreFichero);
  }

  // Menú principal
  int opcion;
  NIF clave;
  while (true) {
    mostrarMenu();
    std::cin >> opcion;
    switch (opcion) {
      case 0:
        std::cout << "Saliendo...\n";
        delete arbol;
        return;
      case 1:
        std::cout << "Introduzca la clave a insertar: ";
        std::cin >> clave;
        if (arbol->insertar(clave)) {
          std::cout << "Clave " << clave << " insertada con éxito.\n";
          arbol->visualizar();
        } else {
          std::cout << "La clave " << clave << " ya existe en el árbol.\n";
        }
        break;
      case 2:
        std::cout << "Introduzca la clave a buscar: ";
        std::cin >> clave;
        if (arbol->buscar(clave)) {
          std::cout << "Clave " << clave << " encontrada.\n";
        } else {
          std::cout << "Clave " << clave << " no encontrada.\n";
        }
        break;
      case 3:
        std::cout << "Árbol en inorden: ";
        arbol->inorden();
        break;
      default:
        std::cout << "Opción no válida. Intente de nuevo.\n";
    }
  }
}

#endif  // FUNCIONES_H
// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Algortimos y Estructuras de Datos Avanzadas
// Curso: 2º
// Práctica 6: Implementación de TDA
// Autor: Pablo García de los Reyes
// Correo: alu0101630045@ull.edu.es
// Fecha: 30/04/2025
// Archivo NodoB.h: Archivo de cabecera de la clase NodoB
// Contiene la declaración de la clase NodoB para su uso en los AB

#ifndef NODOB_H
#define NODOB_H

#include "includes.h"

template <class Key>
class NodoB {
  public:
    NodoB(const Key& k) : dato(k), izdo(nullptr), dcho(nullptr) {}
    // Getters
    Key getDato() const { return dato; }
    NodoB* getIzdo() const { return izdo; }
    NodoB* getDcho() const { return dcho; }
    // Setters
    void setDato(const Key& k) { dato = k; }
    void setIzdo(NodoB* nodo) { izdo = nodo; }
    void setDcho(NodoB* nodo) { dcho = nodo; }
  protected:
    Key dato;
    NodoB* izdo;
    NodoB* dcho;

};

#endif

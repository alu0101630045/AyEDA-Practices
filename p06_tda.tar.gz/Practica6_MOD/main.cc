// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Algoritmos y Estructuras de Datos Avanzadas
// Curso: 2º
// Práctica 6: Implementación de TDA
// Autor: Pablo García de los Reyes
// Correo: alu0101630045@ull.edu.es
// Fecha: 30/04/2025
// Archivo main.cc: Archivo principal del programa

#include <iostream>
#include <cstdlib>
#include <ctime>
#include "includes.h"
#include "Funciones.h"
#include "ABB.h"
#include "AVL.h"
#include "NIF.h"

int main(int argc, char* argv[]) {
  while (true) {
  AB<NIF>* arbol_abb = new ABB<NIF>();
  AVL<NIF>* arbol_avl = new AVL<NIF>(false);

  int cantidad;
  std::cout << "¿Cuántos elementos aleatorios desea generar?" << std::endl;
  std::cin >> cantidad;

  // std::cout << "\nInsertando " << cantidad << " NIFs aleatorios en los árboles...\n";

  for (int i = 0; i < cantidad; ++i) {
    int numero_dni = std::rand() % 90000000 + 10000000;  // 8 dígitos válidos
    NIF nif(numero_dni);

    // std::cout << "Insertando NIF: " << nif << "\n";
    arbol_abb->insertar(nif);
    arbol_avl->insertar(nif);
  }

  // std::cout << "\nÁrbol ABB (por niveles):\n";
  // arbol_abb->visualizar();

  // std::cout << "\nÁrbol AVL (por niveles):\n";
  // arbol_avl->visualizar();

  // Mostrar altura de ambos árboles
  std::cout << "Tras insertar " << cantidad << " NIFs: " << std::endl;
  std::cout << "\nAltura del ABB: " << arbol_abb->Alt() << std::endl;
  std::cout << "Altura del AVL: " << arbol_avl->Alt() << std::endl;

  // Liberar memoria
  delete arbol_abb;
  delete arbol_avl;

  }

  return 0;
}

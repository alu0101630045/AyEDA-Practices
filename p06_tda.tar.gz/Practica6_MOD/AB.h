// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Algortimos y Estructuras de Datos Avanzadas
// Curso: 2º
// Práctica 6: Implementación de TDA
// Autor: Pablo García de los Reyes
// Correo: alu0101630045@ull.edu.es
// Fecha: 30/04/2025
// Archivo AB.h: Archivo de cabecera de la clase AB
// Contiene la declaración de la clase asbtracta Arbol Binario


#ifndef AB_H
#define AB_H

#include "NodoB.h"
#include <queue>
#include <iostream>

template <class Key>
class AB {
  public:
    virtual bool insertar(const Key& k) = 0;
    virtual bool buscar(const Key& k) const = 0;
    virtual void inorden() const = 0;
    virtual void preorden() const = 0;
    virtual void postorden() const = 0;
    virtual void visualizar() const = 0;
    int Alt() { return AltN(raiz); }

  protected:
    NodoB<Key>* raiz = nullptr;
    const int AltN(NodoB<Key>* nodo) {
      if (nodo == nullptr)
          return 0;

      int alt_i = AltN(nodo->getIzdo());
      int alt_d = AltN(nodo->getDcho());

      return (alt_d > alt_i) ? ++alt_d : ++alt_i;
    }
};

#endif // AB_H

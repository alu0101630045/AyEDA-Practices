// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Algoritmos y Estructuras de Datos Avanzadas
// Curso: 2º
// Práctica 6: Implementación de TDA
// Autor: Pablo García de los Reyes
// Correo: alu0101630045@ull.edu.es
// Fecha: 30/04/2025
// Archivo ABB.h: Archivo de cabecera de la clase ABB
// Contiene la declaración de la clase abstracta Árbol Binario de Búsqueda

#ifndef ABB_H
#define ABB_H

#include "NodoB.h"
#include "AB.h"
#include <iostream>
#include <queue>
#include <iomanip> 

template <class Key>
class ABB : public AB<Key> {
public:
    bool insertar(const Key& k) override;
    bool buscar(const Key& k) const override;
    void inorden() const override;
    void preorden() const override;
    void postorden() const override;
    void visualizar() const; // Método de visualización

private:
    void inordenRecursivo(NodoB<Key>* nodo) const;
    void preordenRecursivo(NodoB<Key>* nodo) const;
    void postordenRecursivo(NodoB<Key>* nodo) const;
    void visualizarPorNiveles() const;
};


// --- insertar ---
template <class Key>
bool ABB<Key>::insertar(const Key& k) {
    if (!this->raiz) {
        this->raiz = new NodoB<Key>(k);
        return true;
    }

    NodoB<Key>* actual = this->raiz;

    while (true) {
        if (k < actual->getDato()) {
            if (!actual->getIzdo()) {
                actual->setIzdo(new NodoB<Key>(k));
                return true;
            }
            actual = actual->getIzdo();
        } else if (k > actual->getDato()) {
            if (!actual->getDcho()) {
                actual->setDcho(new NodoB<Key>(k));
                return true;
            }
            actual = actual->getDcho();
        } else {
            return false;  // Duplicado
        }
    }
}

// --- buscar ---
template <class Key>
bool ABB<Key>::buscar(const Key& k) const {
    NodoB<Key>* actual = this->raiz;

    while (actual) {
        if (k == actual->getDato()) {
            return true;
        } else if (k < actual->getDato()) {
            actual = actual->getIzdo();
        } else {
            actual = actual->getDcho();
        }
    }
    return false;
}

// --- inorden ---
template <class Key>
void ABB<Key>::inorden() const {
    inordenRecursivo(this->raiz);
    std::cout << std::endl;
}

template <class Key>
void ABB<Key>::inordenRecursivo(NodoB<Key>* nodo) const {
    if (!nodo) return;
    inordenRecursivo(nodo->getIzdo());
    std::cout << nodo->getDato() << " ";
    inordenRecursivo(nodo->getDcho());
}

// --- preorden ---
template <class Key>
void ABB<Key>::preorden() const {
    preordenRecursivo(this->raiz);
    std::cout << std::endl;
}

template <class Key>
void ABB<Key>::preordenRecursivo(NodoB<Key>* nodo) const {
    if (!nodo) return;
    std::cout << nodo->getDato() << " ";
    preordenRecursivo(nodo->getIzdo());
    preordenRecursivo(nodo->getDcho());
}

// --- postorden ---
template <class Key>
void ABB<Key>::postorden() const {
    postordenRecursivo(this->raiz);
    std::cout << std::endl;
}

template <class Key>
void ABB<Key>::postordenRecursivo(NodoB<Key>* nodo) const {
    if (!nodo) return;
    postordenRecursivo(nodo->getIzdo());
    postordenRecursivo(nodo->getDcho());
    std::cout << nodo->getDato() << " ";
}

// --- visualizar ---
template <class Key>
void ABB<Key>::visualizar() const {
    visualizarPorNiveles();
}

// --- visualizar por niveles ---
template <class Key>
void ABB<Key>::visualizarPorNiveles() const {
    if (!this->raiz) {
        std::cout << "Árbol vacío\n";
        return;
    }

    std::queue<NodoB<Key>*> q;
    q.push(this->raiz);
    int nivel = 0;

    while (!q.empty()) {
        int numNodosNivel = q.size();
        std::cout << "Nivel " << nivel++ << ": ";

        while (numNodosNivel--) {
            NodoB<Key>* nodo = q.front();
            q.pop();

            if (nodo) {
                std::cout << "[" << nodo->getDato() << "] ";
                q.push(nodo->getIzdo());
                q.push(nodo->getDcho());
            } else {
                std::cout << "[.] ";
            }
        }
        std::cout << std::endl;
    }
}

#endif // ABB_H

// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Algortimos y Estructuras de Datos Avanzadas
// Curso: 2º
// Práctica 6: Implementación de TDA
// Autor: Pablo García de los Reyes
// Correo: alu0101630045@ull.edu.es
// Fecha: 30/04/2025
// Archivo AVL.h: Archivo de cabecera de la clase AVL
// Contiene la declaración de la clase asbtracta Arbol Binario de Búsqueda Balanceado

#ifndef AVL_H_
#define AVL_H_

#include "ABB.h"
#include "NodoAVL.h"
#include <deque>
#include <queue>
#include <iostream>

// Clase AVL que hereda de ABB
template <class Key>
class AVL : public ABB<Key> {
 public:
  explicit AVL(bool mostrar_traza = false);
  ~AVL();

  bool insertar(const Key& clave) override;
  bool buscar(const Key& clave) const override;
  void inorden() const override;
  void visualizar() const override;
  int Alt() { return AltN(raiz_); }

 private:
  NodoAVL<Key>* raiz_;
  bool mostrar_traza_;

  const int AltN(NodoAVL<Key>* nodo) {
    if (nodo == nullptr)
        return 0;

    int alt_i = AltN(nodo->izquierdo);
    int alt_d = AltN(nodo->derecho);

    return (alt_d > alt_i) ? ++alt_d : ++alt_i;
  }

  bool BuscarNodo(NodoAVL<Key>* nodo, const Key& clave) const;
  void InsertarBalanceado(NodoAVL<Key>*& nodo, NodoAVL<Key>* nuevo, bool& crece);
  void RebalancearIzquierda(NodoAVL<Key>*& nodo, bool& crece);
  void RebalancearDerecha(NodoAVL<Key>*& nodo, bool& crece);

  void RotacionLL(NodoAVL<Key>*& nodo);
  void RotacionRR(NodoAVL<Key>*& nodo);
  void RotacionLR(NodoAVL<Key>*& nodo);
  void RotacionRL(NodoAVL<Key>*& nodo);

  void InordenRecursivo(NodoAVL<Key>* nodo) const;
  void VisualizarNiveles(NodoAVL<Key>* nodo) const;
};

// Constructor
template <class Key>
AVL<Key>::AVL(bool mostrar_traza) : raiz_(nullptr), mostrar_traza_(mostrar_traza) {}

// Destructor
template <class Key>
AVL<Key>::~AVL() {

}

// Insertar
template <class Key>
bool AVL<Key>::insertar(const Key& clave) {
  if (buscar(clave)) return false;

  if (mostrar_traza_) {
    std::cout << "Insertar: " << clave << std::endl;
  }

  NodoAVL<Key>* nuevo = new NodoAVL<Key>(clave);
  bool crece = false;
  InsertarBalanceado(raiz_, nuevo, crece);

  if (mostrar_traza_) {
    visualizar();
  }

  return true;
}

// Buscar
template <class Key>
bool AVL<Key>::buscar(const Key& clave) const {
  return BuscarNodo(raiz_, clave);
}

// Inorden
template <class Key>
void AVL<Key>::inorden() const {
  InordenRecursivo(raiz_);
  std::cout << std::endl;
}

// Visualizar
template <class Key>
void AVL<Key>::visualizar() const {
  VisualizarNiveles(raiz_);
  std::cout << std::endl;
}

// -------------------------------------------------------
// MÉTODOS PRIVADOS
// -------------------------------------------------------

template <class Key>
bool AVL<Key>::BuscarNodo(NodoAVL<Key>* nodo, const Key& clave) const {
  if (!nodo) return false;
  if (clave == nodo->getDato()) return true;
  if (clave < nodo->getDato()) return BuscarNodo(nodo->izquierdo, clave);
  return BuscarNodo(nodo->derecho, clave);
}

template <class Key>
void AVL<Key>::InsertarBalanceado(NodoAVL<Key>*& nodo, NodoAVL<Key>* nuevo, bool& crece) {
  if (!nodo) {
    nodo = nuevo;
    crece = true;
    return;
  }

  if (nuevo->getDato() < nodo->getDato()) {
    InsertarBalanceado(nodo->izquierdo, nuevo, crece);
    if (crece) RebalancearIzquierda(nodo, crece);
  } else {
    InsertarBalanceado(nodo->derecho, nuevo, crece);
    if (crece) RebalancearDerecha(nodo, crece);
  }
}

template <class Key>
void AVL<Key>::RebalancearIzquierda(NodoAVL<Key>*& nodo, bool& crece) {
  switch (nodo->getBal()) {
    case -1:
      nodo->setBal(0);
      crece = false;
      break;
    case 0:
      nodo->setBal(1);
      break;
    case 1: {
      int balance_actual = nodo->getBal() + 1;  // Le sumamos 1 para que muestre que estaba desbalanceado en 2, porque el balance no se ha actualizado a 2
      if (mostrar_traza_) {
        std::cout << "Desbalanceo en [" << nodo->getDato() << "(" << balance_actual << ")], realizando rotación...\n";
        visualizar();
      }
      if (nodo->izquierdo->getBal() == 1) {
        RotacionLL(nodo);
      } 
      else {
        RotacionLR(nodo);
      }
      crece = false;
      break;
    }
  }
}

template <class Key>
void AVL<Key>::RebalancearDerecha(NodoAVL<Key>*& nodo, bool& crece) {
  switch (nodo->getBal()) {
    case 1:
      nodo->setBal(0);
      crece = false;
      break;
    case 0:
      nodo->setBal(-1);
      break;
    case -1: {
      int balance_actual = nodo->getBal() - 1;  // Le restamos 1 para que muestre que estaba desbalanceado en -2, porque el balance ya se ha actualizado
      if (mostrar_traza_) {
        std::cout << "Desbalanceo en [" << nodo->getDato() << "(" << balance_actual << ")], realizando rotación...\n";
        visualizar();
      }
      if (nodo->derecho->getBal() == -1) {
        RotacionRR(nodo);
      } else {
        RotacionRL(nodo);
      }
      crece = false;
      break;
    }
  }
}

// Rotaciones
template <class Key>
void AVL<Key>::RotacionLL(NodoAVL<Key>*& nodo) {
  if (mostrar_traza_)
    std::cout << "Rotación II (LL) en [" << nodo->getDato() << "(" << nodo->getBal() << ")]\n";


  NodoAVL<Key>* aux = nodo->izquierdo;
  nodo->izquierdo = aux->derecho;
  aux->derecho = nodo;

  nodo->setBal(0);
  aux->setBal(0);

  nodo = aux;
}

template <class Key>
void AVL<Key>::RotacionRR(NodoAVL<Key>*& nodo) {
  if (mostrar_traza_)
    std::cout << "Rotación DD (RR) en ["  << nodo->getDato() << "(" << nodo->getBal() << ")]\n";

  NodoAVL<Key>* aux = nodo->derecho;
  nodo->derecho = aux->izquierdo;
  aux->izquierdo = nodo;

  nodo->setBal(0);
  aux->setBal(0);

  nodo = aux;
}

template <class Key>
void AVL<Key>::RotacionLR(NodoAVL<Key>*& nodo) {
  if (mostrar_traza_)
    std::cout << "Rotación ID en ["  << nodo->getDato() << "(" << nodo->getBal() << ")]\n";

  NodoAVL<Key>* aux1 = nodo->izquierdo;
  NodoAVL<Key>* aux2 = aux1->derecho;

  aux1->derecho = aux2->izquierdo;
  aux2->izquierdo = aux1;
  nodo->izquierdo = aux2->derecho;
  aux2->derecho = nodo;

  if (aux2->getBal() == 1)
    nodo->setBal(-1);
  else
    nodo->setBal(0);

  if (aux2->getBal() == -1)
    aux1->setBal(1);
  else
    aux1->setBal(0);

  aux2->setBal(0);
  nodo = aux2;
}

template <class Key>
void AVL<Key>::RotacionRL(NodoAVL<Key>*& nodo) {
  if (mostrar_traza_)
    std::cout << "Rotación DI en ["  << nodo->getDato() << "(" << nodo->getBal() << ")]\n";

  NodoAVL<Key>* aux1 = nodo->derecho;
  NodoAVL<Key>* aux2 = aux1->izquierdo;

  aux1->izquierdo = aux2->derecho;
  aux2->derecho = aux1;
  nodo->derecho = aux2->izquierdo;
  aux2->izquierdo = nodo;

  if (aux2->getBal() == -1)
    nodo->setBal(1);
  else
    nodo->setBal(0);

  if (aux2->getBal() == 1)
    aux1->setBal(-1);
  else
    aux1->setBal(0);

  aux2->setBal(0);
  nodo = aux2;
}

// Recorrido inorden
template <class Key>
void AVL<Key>::InordenRecursivo(NodoAVL<Key>* nodo) const {
  if (nodo) {
    InordenRecursivo(nodo->izquierdo);
    std::cout << nodo->getDato() << " ";
    InordenRecursivo(nodo->derecho);
  }
}

// Visualizar por niveles
template <class Key>
void AVL<Key>::VisualizarNiveles(NodoAVL<Key>* nodo) const {
  if (!nodo) {
    std::cout << "Árbol vacío\n";
    return;
  }

  std::queue<std::pair<NodoAVL<Key>*, int>> cola;
  cola.push({nodo, 0});
  int nivel_actual = 0;

  std::cout << "Nivel 0: ";

  while (!cola.empty()) {
    NodoAVL<Key>* actual = cola.front().first;
    int nivel = cola.front().second;
    cola.pop();

    if (nivel != nivel_actual) {
      std::cout << "\nNivel " << nivel << ": ";
      nivel_actual = nivel;
    }

    if (actual) {
      if (mostrar_traza_)
        std::cout << "[" << actual->getDato() << "(" << actual->getBal() << ")] ";
      else
        std::cout << "[" << actual->getDato() << "] ";

      cola.push({actual->izquierdo, nivel + 1});
      cola.push({actual->derecho, nivel + 1});
    } else {
      std::cout << "[.] ";
    }
  }
  std::cout << std::endl;
}

#endif  // AVL_H_

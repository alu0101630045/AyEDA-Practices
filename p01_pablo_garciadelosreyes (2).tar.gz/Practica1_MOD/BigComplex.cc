#include "BigComplex.h"

/// @brief Constructor de copia
/// @param complex_param 
BigComplex::BigComplex(const BigComplex& complex_param) {
	real_ = complex_param.real_;
	imag_ = complex_param.imag_;
}

/// @brief Sobrecarga de operador de inserción
/// @param os 
/// @param complex_param 
/// @return os
std::ostream& operator<<(std::ostream& os, const BigComplex& complex_param) {
	os << complex_param.real_ << " + " << complex_param.imag_ << "i" << std::endl;
	return os;
}

/// @brief Sobrecarga de operador de suma
/// @param complex_param1 
/// @param complex_param2 
/// @return complex_result
BigComplex operator+(const BigComplex& complex_param1, const BigComplex& complex_param2) {
	BigInteger real_result = complex_param1.real_ + complex_param2.real_;
	BigInteger imag_result = complex_param1.imag_ + complex_param2.imag_;
	return BigComplex(real_result, imag_result);
}
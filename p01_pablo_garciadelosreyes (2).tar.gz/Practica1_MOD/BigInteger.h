#ifndef BIGINTEGER_H
#define BIGINTEGER_H

#include "BigUnsigned.h"

class BigInteger {
  public:
    // Constructores
    BigInteger(int n = 0);
    BigInteger(const BigUnsigned&);
    BigInteger(const BigInteger&); // Constructor de copia
    // Sobrecarga de operadores
    BigInteger& operator=(const BigInteger& number_param);
    // Inserción/Extracción
    friend std::ostream& operator<<(std::ostream& os, const BigInteger& number_param);
    friend std::istream& operator>>(std::istream& is, BigInteger& number_param);
    // Comparación
    bool operator==(const BigInteger& number_param) const;
    friend bool operator<(const BigInteger& number_param1, const BigInteger& number_param2);
    // Incremento/Decremento
    BigInteger& operator++(); // Pre-incremento
    BigInteger operator++(int); // Post-incremento
    BigInteger& operator--(); // Pre-decremento
    BigInteger operator--(int); // Post-decremento
    // Operadores aritméticos
    friend BigInteger operator+(const BigInteger&, const BigInteger&);
    BigInteger operator-(const BigInteger&) const;
    BigInteger operator*(const BigInteger&) const;
    friend BigInteger operator/(const BigInteger&, const BigInteger&);
    BigInteger operator%(const BigInteger&) const;
    // Métodos extra
    BigInteger mcd(BigInteger a, BigInteger b);
    bool isZero();
  private:
    BigUnsigned number_;
    bool sign_; // true si es negativo, false si es positivo
};

#endif
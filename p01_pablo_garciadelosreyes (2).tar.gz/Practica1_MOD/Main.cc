#include "BigComplex.h"

int main() {
  // Declaración de Big Unsigned
  BigUnsigned example_unsigned(8);
  BigUnsigned example_string((const unsigned char*)"2500");
  BigUnsigned example_copy(example_unsigned);
  BigUnsigned example_from_user;
  BigUnsigned example_from_user2;
  // Declaración de Big Integer
  BigInteger example_integer(12);
  BigInteger example_from_unsigned(example_unsigned);
  BigInteger example_zero((const unsigned char*)"0");
  // Comprobaciones Unsigned
  std::cout << "Introduzca dos números naturales: ";
  std::cin >> example_from_user;
  std::cin >> example_from_user2;
  std::cout << "BigUnsigned from user: " << example_from_user << std::endl;
  std::cout << "BigUnsigned from user2: " << example_from_user2 << std::endl;
  // Operaciones Unsigned
  std::cout << "BigUnsigned + BigUnsigned (" << example_from_user << " + " << example_from_user2 << "): " << example_from_user + example_from_user2 << std::endl;
  std::cout << "BigUnsigned - BigUnsigned (" << example_from_user << " - " << example_from_user2 << "): " << example_from_user - example_from_user2 << std::endl;
  std::cout << "BigUnsigned * BigUnsigned (" << example_from_user << " * " << example_from_user2 << "): " << example_from_user * example_from_user2 << std::endl;
  std::cout << "BigUnsigned / BigUnsigned (" << example_from_user << " / " << example_from_user2 << "): " << example_from_user / example_from_user2 << std::endl;
  std::cout << "BigUnsigned % BigUnsigned (" << example_from_user << " % " << example_from_user2 << "): " << example_from_user % example_from_user2 << std::endl;
  // Comprobaciones Integer
  std::cout << "Introduzca dos números enteros: ";
  BigInteger example_from_user_int;
  BigInteger example_from_user2_int;
  std::cin >> example_from_user_int;
  std::cin >> example_from_user2_int;
  std::cout << "BigInteger from user: " << example_from_user_int << std::endl;
  std::cout << "BigInteger from user2: " << example_from_user2_int << std::endl;
  // Operaciones Integer
  std::cout << "BigInteger + BigInteger (" << example_from_user_int << " + " << example_from_user2_int << "): " << example_from_user_int + example_from_user2_int << std::endl;
  std::cout << "BigInteger - BigInteger (" << example_from_user_int << " - " << example_from_user2_int << "): " << example_from_user_int - example_from_user2_int << std::endl;
  std::cout << "BigInteger * BigInteger (" << example_from_user_int << " * " << example_from_user2_int << "): " << example_from_user_int * example_from_user2_int << std::endl;
  std::cout << "BigInteger / BigInteger (" << example_from_user_int << " / " << example_from_user2_int << "): " << example_from_user_int / example_from_user2_int << std::endl;
  std::cout << "BigInteger % BigInteger (" << example_from_user_int << " % " << example_from_user2_int << "): " << example_from_user_int % example_from_user2_int << std::endl;
  // MCD
  BigInteger a(98765400);
  BigInteger b(11220);
  std::cout << "MCD (" << a << ", " << b << "): " << a.mcd(a, b) << std::endl;
  BigUnsigned large_number((const unsigned char*)"9876543210");
  BigComplex complex_example1(123456789, 123456789);
  BigComplex complex_example2(large_number, -123456788);
  std::cout << complex_example1 << complex_example2;
  std::cout << complex_example1 + complex_example2;

  return 0;
}
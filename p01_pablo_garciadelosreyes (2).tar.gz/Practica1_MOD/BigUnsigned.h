#ifndef BIGUNSIGNED_H
#define BIGUNSIGNED_H

#include <iostream>
#include <vector>

class BigUnsigned {
  public:
    // Constructores
    BigUnsigned(unsigned n = 0);
    BigUnsigned(const unsigned char*);
    BigUnsigned(const BigUnsigned&); // Constructor de copia
    // Sobrecarga de operadores
    BigUnsigned& operator=(const BigUnsigned& number_param);
    // Inserción/Extracción
    friend std::ostream& operator<<(std::ostream& os, const BigUnsigned& number_param);
    friend std::istream& operator>>(std::istream& is, BigUnsigned& number_param);
    // Comparación
    bool operator==(const BigUnsigned& number_param) const;
    friend bool operator<(const BigUnsigned& number_param1, const BigUnsigned& number_param2);
    bool operator>=(const BigUnsigned& number_param) { return *this < number_param || *this == number_param; }
    bool operator<=(const BigUnsigned& number_param) const { return !(*this > number_param); }
    bool operator>(const BigUnsigned& number_param) const { return !(*this <= number_param) && !(*this == number_param); }
    // Incremento/Decremento
    BigUnsigned& operator++(); // Pre-incremento
    BigUnsigned operator++(int); // Post-incremento
    BigUnsigned& operator--(); // Pre-decremento
    BigUnsigned operator--(int); // Post-decremento
    // Operadores aritméticos
    friend BigUnsigned operator+(const BigUnsigned&, const BigUnsigned&);
    BigUnsigned operator-(const BigUnsigned&) const;
    BigUnsigned operator*(const BigUnsigned&) const;
    friend BigUnsigned operator/(const BigUnsigned&, const BigUnsigned&);
    BigUnsigned operator%(const BigUnsigned&) const;
    // Getter
    std::vector<unsigned char> getDigitsVec() const { return digits_vec_; }
  private:
    std::vector<unsigned char> digits_vec_;
};

#endif 
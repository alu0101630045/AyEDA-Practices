#include "BigUnsigned.h"

/// @brief Constructor a partir de un número natural
/// @param n 
BigUnsigned::BigUnsigned(unsigned n) {
  if (n == 0) {
    digits_vec_.push_back(0);
    digits_vec_.pop_back();
  }
  else {
    while (n != 0) {
      digits_vec_.push_back(n % 10);
      n /= 10;
    }
  }
}



/// @brief Constructor a partir de una cadena
/// @param unsigned char*
BigUnsigned::BigUnsigned(const unsigned char* unprocessed_digits) {
  std::string new_digits = std::string(reinterpret_cast<const char*>(unprocessed_digits));
  if (!new_digits.empty()) {
    for (int i = new_digits.size() - 1; i >= 0; i--) {
      if (new_digits[i] <= '9' && new_digits[i] >= '0' )
        digits_vec_.push_back((new_digits[i]) - '0'); // Pasar de ASCII a número
      else {
        std::cerr << "La cadena no es númerica." << std::endl;
        exit(EXIT_FAILURE);
      }
    }
  }
}



/// @brief Constructor de copia
/// @param BigUnsigned& copy
BigUnsigned::BigUnsigned(const BigUnsigned& copy) : digits_vec_(copy.digits_vec_) {} 



/// @brief Sobrecarga de operador de copia
/// @param  number_param
/// @return number_result
BigUnsigned& BigUnsigned::operator=(const BigUnsigned& number_param) {
  if (this != &number_param) {
    digits_vec_ = number_param.digits_vec_;
  }
  return *this;
}



/// @brief Sobrecarga de operador de inserción
/// @param os 
/// @param number_param 
/// @return os
std::ostream& operator<<(std::ostream& os, const BigUnsigned& number_param) {
  for (int i = number_param.digits_vec_.size() - 1; i >= 0; i--) {
    os << static_cast<unsigned>(number_param.digits_vec_[i]);
  }
  return os;
}



/// @brief Sobrecarga de operador de extracción
/// @param is 
/// @param number_param 
/// @return is
std::istream& operator>>(std::istream& is, BigUnsigned& number_param) {
  std::string input;
  is >> input;
  number_param.digits_vec_.clear();
  for (int i = input.size() - 1; i >= 0; i--) {
    if (input[i] >= '0' && input[i] <= '9') {
      number_param.digits_vec_.push_back(input[i] - '0');
    } else {
      std::cerr << "La cadena no es numérica." << std::endl;
      exit(EXIT_FAILURE);
    }
  }
  return is;
}



/// @brief Sobrecarga de operador de igualdad 
/// @param number_param 
/// @return true si son iguales, false si no lo son 
bool BigUnsigned::operator==(const BigUnsigned& number_param) const {
  if (digits_vec_.size() != number_param.digits_vec_.size()) {
    return false;
  }
  for (int i = 0; i < digits_vec_.size(); i++) {
    if (digits_vec_[i] != number_param.digits_vec_[i]) {
      return false;
    }
  }
  return true;
}



/// @brief Sobrecarga de operador de menor que 
/// @param number_param1 
/// @param number_param2 
/// @return true si es menor, false si no lo es 
bool operator<(const BigUnsigned& number_param1, const BigUnsigned& number_param2) {
  if (number_param1.digits_vec_.size() < number_param2.digits_vec_.size()) {
    return true;
  }
  else if (number_param1.digits_vec_.size() > number_param2.digits_vec_.size()) {
    return false;
  }
  else {
    for (int i = number_param1.digits_vec_.size() - 1; i >= 0; i--) {
      if (number_param1.digits_vec_[i] < number_param2.digits_vec_[i]) {
        return true;
      }
      else if (number_param1.digits_vec_[i] > number_param2.digits_vec_[i]) {
        return false;
      }
    }
  }
  return false;
}


/// @brief Sobrecarga de operador de menor o igual 
/// @param number_param1 
/// @param number_param2 
/// @return true si es menor o igual, false si no lo es 
bool operator>=(const BigUnsigned& number_param1, const BigUnsigned& number_param2) {
  if (number_param1.getDigitsVec().size() > number_param2.getDigitsVec().size()) {
    return true;
  } 
  else if (number_param1.getDigitsVec().size() < number_param2.getDigitsVec().size()) {
    return false;
  } 
  else {
    for (int i = number_param1.getDigitsVec().size() - 1; i >= 0; i--) {
      if (number_param1.getDigitsVec()[i] > number_param2.getDigitsVec()[i]) {
        return true;
      } 
      else if (number_param1.getDigitsVec()[i] < number_param2.getDigitsVec()[i]) {
        return false;
      }
    }
  }
  return true;  // Si son iguales, retorna `true`
}



/// @brief Sobrecarga de operador de suma
/// @param number_param1 
/// @param number_param2 
/// @return number_result
BigUnsigned operator+(const BigUnsigned& number_param1, const BigUnsigned& number_param2) {
  BigUnsigned number_result;
  int carry = 0;
  for (int i = 0; i < number_param1.digits_vec_.size() || i < number_param2.digits_vec_.size(); i++) {
    int sum = carry;
    if (i < number_param1.digits_vec_.size()) { // Si A es más corto que B
      sum += number_param1.digits_vec_[i];
    }
    if (i < number_param2.digits_vec_.size()) { // Si B es más corto que A
      sum += number_param2.digits_vec_[i];
    }
    if (sum >= 10) { // Si la suma es mayor o igual a 10
      sum -= 10;
      carry = 1; // Hay acarreo
    }
    else {
      carry = 0;
    } 
    number_result.digits_vec_.push_back(sum); 
  }
  if (carry) { // Si hay acarreo
    number_result.digits_vec_.push_back(carry);
  } 
  return number_result;
}



/// @brief Sobrecarga de operador de resta
/// @param number_param 
/// @return number_result
BigUnsigned BigUnsigned::operator-(const BigUnsigned& number_param) const {
  BigUnsigned number_result;
  unsigned borrow = 0;
  unsigned difference = 0;
  // Si A < B, retornar 0 ya que BigUnsigned no admite negativos
  if (*this < number_param) {
    return BigUnsigned((const unsigned char*)"0");
  }
  // Resta de los números
  for (size_t i = 0; i < digits_vec_.size(); i++) { // Recorrer los dígitos de A
    unsigned digitA = digits_vec_[i];  // Dígito actual de A
    unsigned digitB = (i < number_param.digits_vec_.size()) ? number_param.digits_vec_[i] : 0; // Si B es más corto que A
    if (digitA < digitB + borrow) {  // Si necesitamos pedir prestado
      digitA += 10; // Sumamos 10 al dígito actual
      difference = digitA - (digitB + borrow); // Restamos B y el préstamo
      borrow = 1;  // Marcamos que hay préstamo para la siguiente iteración
    } else { // Si no necesitamos pedir prestado
      difference = digitA - (digitB + borrow); // Restamos B y el préstamo
      borrow = 0; // No hay préstamo
    }
    number_result.digits_vec_.push_back(difference);
  }
  // Eliminar ceros a la izquierda correctamente
  while (number_result.digits_vec_.size() > 1 && number_result.digits_vec_.back() == 0) {
    number_result.digits_vec_.pop_back();
  }
  return number_result;
}




/// @brief Sobrecarga de operador de multiplicación 
/// @param number_param 
/// @return number_result 
BigUnsigned BigUnsigned::operator*(const BigUnsigned& number_param) const {
  BigUnsigned number_result;
  number_result.digits_vec_.resize(digits_vec_.size() + number_param.digits_vec_.size(), 0); // Inicializar a 0 y con el tamaño adecuado (A*B)
  for (int i = 0; i < digits_vec_.size(); i++) { // Recorrer los dígitos de A
    int carry = 0;
    for (int j = 0; j < number_param.digits_vec_.size() || carry != 0; j++) { // Recorrer los dígitos de B
      int product = number_result.digits_vec_[i + j] + carry; // Sumar el producto actual y el acarreo
      if (j < number_param.digits_vec_.size()) { // Si B es más corto que A
        product += digits_vec_[i] * number_param.digits_vec_[j]; // Multiplicar los dígitos de A y B
      }
      number_result.digits_vec_[i + j] = product % 10; // Guardar el dígito actual
      carry = product / 10; // Guardar el acarreo
    }
  }
  // Eliminar ceros a la izquierda
  while (number_result.digits_vec_.size() > 1 && number_result.digits_vec_.back() == 0) {
    number_result.digits_vec_.pop_back();
  }
  return number_result;
}



/// @brief Sobrecarga de operador de división
/// @param number_param1 
/// @param number_param2  
/// @return number_result 
BigUnsigned operator/(const BigUnsigned& number_param1, const BigUnsigned& number_param2) {
  BigUnsigned number_result((const unsigned char*)"0");
  BigUnsigned temp = number_param1;
  while (number_param2 < temp ) { // Mientras B sea menor que A
    temp = temp - number_param2; // Restar B a A
    ++number_result; // Incrementar el resultado (cociente)
  }
  if (temp == number_param2) { // Si A es igual a B
    ++number_result; // Incrementar el resultado (cociente)
    temp = temp - number_param2; // Restar B a A
  }
  return number_result;
}



/// @brief 
/// @param number_param 
/// @return 
BigUnsigned BigUnsigned::operator%(const BigUnsigned& number_param) const {
  BigUnsigned c; // Cociente
  c = *this / number_param; // Calcular el cociente
  BigUnsigned r = *this - (c * number_param);  // Calcular el resto
  return r;
}



/// @brief 
/// @return
BigUnsigned& BigUnsigned::operator++() {
  *this = *this + 1;
  return *this;
}



/// @brief
/// @return
BigUnsigned BigUnsigned::operator++(int) {
  BigUnsigned temp = *this;
  *this = *this + 1;
  return temp;
}



/// @brief
/// @return
BigUnsigned& BigUnsigned::operator--() {
  *this = *this - 1;
  return *this;
}



/// @brief
/// @return
BigUnsigned BigUnsigned::operator--(int) {
  BigUnsigned temp = *this;
  *this = *this - 1;
  return temp;
}
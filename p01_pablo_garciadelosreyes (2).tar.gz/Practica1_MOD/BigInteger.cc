#include "BigInteger.h"

/// @brief Constructor a partir de un número entero
/// @param n
BigInteger::BigInteger(int n) {
  if (n == 0) {
    number_ = BigUnsigned(n = 0);
    sign_ = false;
  }
  else {
    if (n < 0) {
      sign_ = true;
      n = -n;
    }
    else {
      sign_ = false;
    }
    number_ = BigUnsigned(n);
  }
}

/// @brief Constructor a partir de un BigUnsigned
/// @param number_param
BigInteger::BigInteger(const BigUnsigned& number_param) {
  number_ = number_param;
  sign_ = false;
}

/// @brief Constructor de copia
/// @param copy
BigInteger::BigInteger(const BigInteger& copy) : number_(copy.number_), sign_(copy.sign_) {}

/// @brief Sobrecarga de operador de copia
/// @param number_param
/// @return number_result
BigInteger& BigInteger::operator=(const BigInteger& number_param) {
  if (this != &number_param) {
    number_ = number_param.number_;
    sign_ = number_param.sign_;
  }
  return *this;
}

/// @brief Sobrecarga de operador de inserción
/// @param os
/// @param number_param
/// @return os
std::ostream& operator<<(std::ostream& os, const BigInteger& number_param) {
  if (number_param.sign_) {
    os << "-";
  }
  os << number_param.number_;
  return os;
}

/// @brief Sobrecarga de operador de extracción
/// @param is
/// @param number_param
/// @return is
std::istream& operator>>(std::istream& is, BigInteger& number_param) {
  int user_number;
  is >> user_number;
  if (user_number < 0) {
    number_param.sign_ = true;
    user_number = -user_number;
  }
  else {
    number_param.sign_ = false;
  }
  number_param.number_ = BigUnsigned(user_number);
  return is;
}

/// @brief
/// @param number_param
/// @return
bool BigInteger::operator==(const BigInteger& number_param) const {
  return (sign_ == number_param.sign_) && (number_ == number_param.number_);
}

/// @brief
/// @param number_param1
/// @param number_param2
/// @return
bool operator<(const BigInteger& number_param1, const BigInteger& number_param2) {
  if (number_param1.sign_ && !number_param2.sign_) {
    return true;
  }
  else if (!number_param1.sign_ && number_param2.sign_) {
    return false;
  }
  else if (number_param1.sign_ && number_param2.sign_) {
    return number_param2.number_ < number_param1.number_;
  }
  else {
    return number_param1.number_ < number_param2.number_;
  }
}

/// @brief
/// @return
BigInteger& BigInteger::operator++() {
  *this = *this + 1;
  return *this;
}

/// @brief
/// @return
BigInteger BigInteger::operator++(int) {
  BigInteger temp = *this;
  *this = *this + 1;
  return temp;
}

/// @brief
/// @return
BigInteger& BigInteger::operator--() {
  *this = *this - 1;
  return *this;
}

/// @brief
/// @return
BigInteger BigInteger::operator--(int) {
  BigInteger temp = *this;
  *this = *this - 1;
  return temp;
}

/// @brief
/// @param number_param1
/// @param number_param2
/// @return
BigInteger operator+(const BigInteger& number_param1, const BigInteger& number_param2) {
  BigInteger number_result;
  if (number_param1.sign_ == number_param2.sign_) {
    // Ambos números tienen el mismo signo
    number_result.number_ = number_param1.number_ + number_param2.number_;
    number_result.sign_ = number_param1.sign_;
  } 
  else {
    // Los números tienen signos diferentes
    if (number_param1.number_ < number_param2.number_) {
      number_result.number_ = number_param2.number_ - number_param1.number_;
      number_result.sign_ = number_param2.sign_;
    } else {
      number_result.number_ = number_param1.number_ - number_param2.number_;
      number_result.sign_ = number_param1.sign_;
    }
  }
  return number_result;
}

/// @brief
/// @param number_param
/// @return
BigInteger BigInteger::operator-(const BigInteger& number_param) const {
  BigInteger number_result;
  if (sign_ == number_param.sign_) {
    if (number_ < number_param.number_) {
      number_result.number_ = number_param.number_ - number_;
      number_result.sign_ = !sign_;
    }
    else {
      number_result.number_ = number_ - number_param.number_;
      number_result.sign_ = sign_;
    }
  }
  else {
    number_result.number_ = number_ + number_param.number_;
    number_result.sign_ = sign_;
  }
  return number_result;
}

/// @brief
/// @param number_param
/// @return
BigInteger BigInteger::operator*(const BigInteger& number_param) const {
  BigInteger number_result;
  number_result.number_ = number_ * number_param.number_;
  number_result.sign_ = sign_ != number_param.sign_;
  return number_result;
}

/// @brief
/// @param number_param1
/// @param number_param2
/// @return
BigInteger operator/(const BigInteger& number_param1, const BigInteger& number_param2) {
  BigInteger number_result;
  number_result.number_ = number_param1.number_ / number_param2.number_;
  number_result.sign_ = number_param1.sign_ != number_param2.sign_;
  return number_result;
}

/// @brief
/// @param number_param
/// @return
BigInteger BigInteger::operator%(const BigInteger& number_param) const {
  BigInteger number_result;
  number_result.number_ = number_ % number_param.number_;
  number_result.sign_ = false;
  return number_result;
}

/// @brief Algoritmo RECURSIVO de Euclides para calcular el máximo común divisor
/// @param a
/// @param b
/// @return mcd
BigInteger BigInteger::mcd(BigInteger a, BigInteger b) {
  // mcd(a,0) = a
  // mcd(a,b) = mcd(b,a%b)
  if (b.isZero()) {
    return a;
  }
  else {
    BigInteger resto = a % b;
    return mcd(b, resto);
  }
}

/// @brief Comprueba si el número es 0 
/// @return true si es 0, false si no lo es 
bool BigInteger::isZero() {
  std::vector<unsigned char> zero_vec = {0};
  return number_.getDigitsVec() == zero_vec;
}
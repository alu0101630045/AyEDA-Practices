#ifndef BIGCOMPLEX_H
#define BIGCOMPLEX_H

#include "BigInteger.h"

class BigComplex {
  public:
		// Constructor por parámetros
		BigComplex(BigInteger real, BigInteger imag) : real_(real), imag_(imag) {}
		// Constructor por defecto
		BigComplex() = default;
		// Constructor de copia
		BigComplex(const BigComplex& complex_param);
		// Sobrecarga de operadores
		friend std::ostream& operator<<(std::ostream& os, const BigComplex& complex_param);
		friend BigComplex operator+(const BigComplex& complex_param1, const BigComplex& complex_param2);
  private:
		BigInteger real_;
		BigInteger imag_;

};



#endif
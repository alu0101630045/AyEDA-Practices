// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 8: Gramáticas en Forma Normal de Chomsky
// Autor: Diego Vegas Acosta
// Correo: alu0101651361@ull.edu.es
// Fecha: 29/10/2024
// Archivo produccion.h: Declaración de la clase producción
// Referencias: 
// Enlaces de interés
// Historial de revisiones
// 29/10/2024 - Creación (primera versión) del código

#ifndef FUNCIONES_H
#define FUNCIONES_H

#include "BigRational.h"

#include <sstream>
#include <fstream>

unsigned char ObtenerBase() {
  std::ifstream archivo("Ejemplo_Base2.txt");
  std::string linea;
  unsigned char base;
  std::getline(archivo, linea);
  std::string baseStr = linea.substr(7);
  base = std::stoi(baseStr);
  return base;
}

std::vector<std::string> ObtenerNumeros() {
  std::ifstream archivo("Ejemplo_Base2.txt");
  std::string linea;
  std::vector<std::string> numeros(4); // Vector de 4 posiciones

  // Variables para almacenar los numeradores y denominadores
  std::string numerador1, denominador1, numerador2, denominador2;

  // Leer línea por línea el archivo
  while(std::getline(archivo, linea)) {
    if(linea.find("N1 =") != std::string::npos) {
      // Encontramos la línea de N1
      std::stringstream ss(linea.substr(5)); // Quitar "N1 ="
      char slash;
      ss >> numerador1 >> slash >> denominador1; // Leer numerador y denominador de N1
    }
    else if(linea.find("N2 =") != std::string::npos) {
      // Encontramos la línea de N2
      std::stringstream ss(linea.substr(5)); // Quitar "N2 ="
      char slash;
      ss >> numerador2 >> slash >> denominador2; // Leer numerador y denominador de N2
    }
 }
  // Guardar los valores en el vector
  numeros[0] = numerador1;  // Numerador de N1
  numeros[1] = denominador1; // Denominador de N1
  numeros[2] = numerador2;  // Numerador de N2
  numeros[3] = denominador2; // Denominador de N2

  return numeros;
}

std::vector<std::string> ObtenerComplejos() {
  // Base = 10
  // N1 = -1234567890 + 617283945i
  // N2 = 1234567890 - 246913578i
  std::ifstream archivo("BigComplex_Base2.txt");
  std::string linea;
  std::vector<std::string> numeros(4); // Vector de 4 posiciones
  while (std::getline(archivo, linea)) {
    if (linea.find("N1 =") != std::string::npos) {
      // Encontramos la línea de N1
      std::stringstream ss(linea.substr(5)); // Quitar "N1 ="
      char signo;
      ss >> numeros[0] >> signo >> numeros[1]; // Leer parte real e imaginaria de N1
    }
    else if (linea.find("N2 =") != std::string::npos) {
      // Encontramos la línea de N2
      std::stringstream ss(linea.substr(5)); // Quitar "N2 ="
      char signo;
      ss >> numeros[2] >> signo >> numeros[3]; // Leer parte real e imaginaria de N2
      // Ponemos el signo a la parte imaginaria
      if (numeros[3][0] == '-') {
        numeros[3] = "-" + numeros[3].substr(1);
      }
      else {
        numeros[3] = "+" + numeros[3];
      }
    }
  }
  return numeros;
}

// NOTA: Al imprimir los racionales tambien imprimo el resultado de la división entre el numerador y denominador,
// de esta manera puedo comparar resultados de manera más rápida y eficiente para mí.


void Imprimir10(BigRational<10> primero, BigRational<10> segundo) {
  // Base = 10
  // N1 = -442142117615672 / 46651367647546
  // N2 = 46651367647546 / 442142117615672
  // N1 ==N2: false
  // N1 < N2: true
  // N1+N2: …
  std::ofstream salida("output.txt");
  salida << "Base = 10\n";
  salida << "N1 = " << primero << "\n";
  salida << "N2 = " << segundo << "\n";
  salida << "N1 == N2: "; 
  if(primero == segundo) {
    salida << "true\n";
  }
  else {
    salida << "false\n";
  }
  salida << "N1 < N2: "; 
  if(primero < segundo) {
    salida << "true\n";
  }
  else {
    salida << "false\n";
  }
  BigRational<10> suma = primero + segundo;
  salida << "N1 + N2: " << suma << " = " << suma.GetResult() << "\n";

  BigRational<10> resta = primero - segundo;
  salida << "N1 - N2: " << resta << " = " << resta.GetResult() << "\n";

  BigRational<10> multi = primero * segundo;
  salida << "N1 * N2: " << multi << " = " << multi.GetResult() << "\n";

  BigRational<10> div = primero / segundo;
  salida << "N1 / N2: " << div << " = " << div.GetResult() <<"\n";
}

void Imprimir2(BigRational<2> primero, BigRational<2> segundo) {
  std::ofstream salida("output.txt");

  salida << "Base = 2\n";
  salida << "N1 = " << primero << "\n";
  salida << "N2 = " << segundo << "\n";
  salida << "N1 == N2: "; 
  if(primero == segundo) {
    salida << "true\n";
  }
  else {
    salida << "false\n";
  }
  salida << "N1 < N2: "; 
  if(primero < segundo) {
    salida << "true\n";
  }
  else {
    salida << "false\n";
  }
  BigRational<2> suma = primero + segundo;
  salida << "N1 + N2: " << suma << " = " << suma.GetResult() << "\n";

  BigRational<2> resta = primero - segundo;
  salida << "N1 - N2: " << resta << " = " << resta.GetResult() << "\n";

  BigRational<2> multi = primero * segundo;
  salida << "N1 * N2: " << multi << " = " << multi.GetResult() << "\n";

  BigRational<2> div = primero / segundo;
  salida << "N1 / N2: " << div << " = " << div.GetResult() <<"\n";
}


void Imprimir8(BigRational<8> primero, BigRational<8> segundo) {
  std::ofstream salida("output.txt");
  salida << "Base = 8\n";
  salida << "N1 = " << primero << "\n";
  salida << "N2 = " << segundo << "\n";
  salida << "N1 == N2: "; 
  if(primero == segundo) {
    salida << "true\n";
  }
  else {
    salida << "false\n";
  }
  salida << "N1 < N2: "; 
  if(primero < segundo) {
    salida << "true\n";
  }
  else {
    salida << "false\n";
  }
  BigRational<8> suma = primero + segundo;
  salida << "N1 + N2: " << suma << " = " << suma.GetResult() << "\n";

  BigRational<8> resta = primero - segundo;
  salida << "N1 - N2: " << resta << " = " << resta.GetResult() << "\n";

  BigRational<8> multi = primero * segundo;
  salida << "N1 * N2: " << multi << " = " << multi.GetResult() << "\n";

  BigRational<8> div = primero / segundo;
  salida << "N1 / N2: " << div << " = " << div.GetResult() <<"\n";
}

void Imprimir16(BigRational<16> primero, BigRational<16> segundo) {
  std::ofstream salida("output.txt");
  salida << "Base = 16\n";
  salida << "N1 = " << primero << "\n";
  salida << "N2 = " << segundo << "\n";
  salida << "N1 == N2: "; 
  if(primero == segundo) {
    salida << "true\n";
  }
  else {
    salida << "false\n";
  }
  salida << "N1 < N2: "; 
  if(primero < segundo) {
    salida << "true\n";
  }
  else {
    salida << "false\n";
  }
  BigRational<16> suma = primero + segundo;
  salida << "N1 + N2: " << suma << " = " << suma.GetResult() << "\n";

  BigRational<16> resta = primero - segundo;
  salida << "N1 - N2: " << resta << " = " << resta.GetResult() << "\n";

  BigRational<16> multi = primero * segundo;
  salida << "N1 * N2: " << multi << " = " << multi.GetResult() << "\n";

  BigRational<16> div = primero / segundo;
  salida << "N1 / N2: " << div << " = " << div.GetResult() <<"\n";
}

#endif
#ifndef BIGCOMPLEX_H
#define BIGCOMPLEX_H

#include "BigInteger.h"

template <unsigned char Base>
class BigComplex {
  public:
		// Constructor por parámetros
		BigComplex(BigInteger<Base> real, BigInteger<Base> imag) : real_(real), imag_(imag) {}
		// Constructor por defecto
		BigComplex() = default;
		// Constructor de copia
		BigComplex(const BigComplex<Base>& complex_param);
		// Sobrecarga de operadores
		template <unsigned char B>
		friend std::ostream& operator<<(std::ostream& os, const BigComplex& complex_param);
		template <unsigned char B>
		friend BigComplex operator+(const BigComplex& complex_param1, const BigComplex& complex_param2);
		// Getters
		BigInteger<Base> real() const { return real_; }
		BigInteger<Base> imag() const { return imag_; }
  private:
		BigInteger<Base> real_;
		BigInteger<Base> imag_;
};

/// @brief Constructor de copia
/// @param complex_param 
template <unsigned char Base>
BigComplex<Base>::BigComplex(const BigComplex<Base>& complex_param) {
	real_ = complex_param.real_;
	imag_ = complex_param.imag_;
}

/// @brief Sobrecarga de operador de inserción
/// @param os 
/// @param complex_param 
/// @return os
template <unsigned char B>
std::ostream& operator<<(std::ostream& os, const BigComplex<B>& complex_param) {
	if (complex_param.imag().GetSigno() == false) 
		os << complex_param.real() << " + " << complex_param.imag() << "i" << std::endl;
	else
		os << complex_param.real() << "  " << complex_param.imag() << "i" << std::endl;
	return os;
}

/// @brief Sobrecarga de operador de suma
/// @param complex_param1 
/// @param complex_param2 
/// @return complex_result
template <unsigned char B>
BigComplex<B> operator+(const BigComplex<B>& complex_param1, const BigComplex<B>& complex_param2) {
	BigInteger real_result = complex_param1.real() + complex_param2.real();
	BigInteger imag_result = complex_param1.imag() + complex_param2.imag();
	return BigComplex(real_result, imag_result);
}

#endif
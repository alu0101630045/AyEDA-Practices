#include "Funciones.h"
#include "BigComplex.h"

int main() {
  unsigned char base = ObtenerBase();
  std::vector<std::string> numeros = ObtenerNumeros();
  if (base == 10) {
    // Primer numero
    std::string num1 = numeros[0];
    BigUnsigned<10> unsig_num1((const unsigned char*)num1.c_str());
    BigInteger<10> big_num1(unsig_num1);
    BigUnsigned<10> den1((const unsigned char*)numeros[1].c_str());
    // Segundo numero
    std::string num2 = numeros[2];
    BigUnsigned<10> unsig_num2((const unsigned char*)num2.c_str());
    BigInteger<10> big_num2(unsig_num2);
    BigUnsigned<10> den2((const unsigned char*)numeros[3].c_str());
    // Crear racionales
    BigRational<10> primero(big_num1, den1);
    BigRational<10> segundo(big_num2, den2);
    Imprimir10(primero, segundo);
  }
  else if (base == 2) {
    // Primer numero
    std::string num1_str = numeros[0];
    BigInteger<2> big_num1(num1_str.c_str());
    BigUnsigned<2> den1((const unsigned char*)numeros[1].c_str());
    // Segundo numero
    BigInteger<2> big_num2(numeros[2].c_str());
    BigUnsigned<2> den2((const unsigned char*)numeros[3].c_str());
    // Crear racionales
    BigRational<2> primero(big_num1, den1);
    BigRational<2> segundo(big_num2, den2);
    Imprimir2(primero, segundo);
  }
  else if (base == 16) {
    // Primer numero
    BigUnsigned<16> unsig_num1((const unsigned char*)numeros[0].c_str());
    BigInteger<16> big_num1(unsig_num1);
    BigUnsigned<16> den1((const unsigned char*)numeros[1].c_str());
    // Segundo numero
    BigUnsigned<16> unsig_num2((const unsigned char*)numeros[2].c_str());
    BigInteger<16> big_num2(unsig_num2);
    BigUnsigned<16> den2((const unsigned char*)numeros[3].c_str());
    // Crear racionales
    BigRational<16> primero(big_num1, den1);
    BigRational<16> segundo(big_num2, den2);
    Imprimir16(primero, segundo);
  }
  else if (base == 8) {
    // Primer numero
    BigInteger<8> big_num1(numeros[0].c_str());
    BigUnsigned<8> den1((const unsigned char*)numeros[1].c_str());
    // Segundo numero
    BigInteger<8> big_num2(numeros[2].c_str());
    BigUnsigned<8> den2((const unsigned char*)numeros[3].c_str());
    // Crear racionales
    BigRational<8> primero(big_num1, den1);
    BigRational<8> segundo(big_num2, den2);
    Imprimir8(primero, segundo);
  }
  // // Prueba complejos
  // std::vector<std::string> complejos = ObtenerComplejos();
  // BigInteger<8> real1(complejos[0].c_str());
  // BigInteger<8> real2(complejos[1].c_str());
  // BigInteger<8> imag1(complejos[2].c_str());
  // BigInteger<8> imag2(complejos[3].c_str());
  // BigComplex<8> complejo1(real1, imag1);
  // BigComplex<8> complejo2(real2, imag2);
  // std::cout << complejo1 << std::endl;
  // std::cout << complejo2 << std::endl;
  // BigComplex<8> suma = complejo1 + complejo2;
  // std::cout << suma << std::endl;
  std::ofstream salida("output.txt", std::ios::app);
  salida << "OPERACIONES DE COMPLEX" << std::endl;
  BigInteger<10> real1("-1234567890");
  BigInteger<10> imag1("617283945");
  BigInteger<10> real2("1234567890");
  BigInteger<10> imag2("-246913578");
  BigComplex<10> complejo1(real1, imag1);
  BigComplex<10> complejo2(real2, imag2);
  salida << complejo1;
  salida << complejo2 << std::endl;
  BigComplex<10> suma = complejo1 + complejo2;
  salida << suma << std::endl;
  return 0;
}





  
#include "functions.h"
#include <chrono>
#include <iostream>

using namespace std::chrono;

int main(int argc, const char *const argv[]) {
    staticSequence<NIF> sequence1(100);
    staticSequence<NIF> sequence2(10000);
    staticSequence<NIF> sequence3(100000);

    sequence1.fill_random(100);
    sequence2.fill_random(10000);
    sequence3.fill_random(100000);

    // Insertion Sort
    std::cout << "Insertion Sort" << std::endl;
    SortMethod<NIF>* insertionSort = new InsertionSort<NIF>();

    staticSequence<NIF> s1_ins(sequence1), s2_ins(sequence2), s3_ins(sequence3);
    auto start = high_resolution_clock::now();
    insertionSort->sort(s1_ins, 100, false);
    auto end = high_resolution_clock::now();
    std::cout << "N = 100: " << duration_cast<milliseconds>(end - start).count() << " ms" << std::endl;

    start = high_resolution_clock::now();
    insertionSort->sort(s2_ins, 10000, false);
    end = high_resolution_clock::now();
    std::cout << "N = 10000: " << duration_cast<milliseconds>(end - start).count() << " ms" << std::endl;

    start = high_resolution_clock::now();
    insertionSort->sort(s3_ins, 100000, false);
    end = high_resolution_clock::now();
    std::cout << "N = 100000: " << duration_cast<milliseconds>(end - start).count() << " ms" << std::endl;


    // Shake Sort
    std::cout << "Shake Sort" << std::endl;
    SortMethod<NIF>* shakeSort = new ShakeSort<NIF>();

    staticSequence<NIF> s1_shake(sequence1), s2_shake(sequence2), s3_shake(sequence3);
    start = high_resolution_clock::now();
    shakeSort->sort(s1_shake, 100, false);
    end = high_resolution_clock::now();
    std::cout << "N = 100: " << duration_cast<milliseconds>(end - start).count() << " ms" << std::endl;

    start = high_resolution_clock::now();
    shakeSort->sort(s2_shake, 10000, false);
    end = high_resolution_clock::now();
    std::cout << "N = 10000: " << duration_cast<milliseconds>(end - start).count() << " ms" << std::endl;

    start = high_resolution_clock::now();
    shakeSort->sort(s3_shake, 100000, false);
    end = high_resolution_clock::now();
    std::cout << "N = 100000: " << duration_cast<milliseconds>(end - start).count() << " ms" << std::endl;

    delete shakeSort;

    // Quick Sort
    std::cout << "Quick Sort" << std::endl;
    SortMethod<NIF>* quickSort = new QuickSort<NIF>();

    staticSequence<NIF> s1_quick(sequence1), s2_quick(sequence2), s3_quick(sequence3);
    start = high_resolution_clock::now();
    quickSort->sort(s1_quick, 100, false);
    end = high_resolution_clock::now();
    std::cout << "N = 100: " << duration_cast<milliseconds>(end - start).count() << " ms" << std::endl;

    start = high_resolution_clock::now();
    quickSort->sort(s2_quick, 10000, false);
    end = high_resolution_clock::now();
    std::cout << "N = 10000: " << duration_cast<milliseconds>(end - start).count() << " ms" << std::endl;

    start = high_resolution_clock::now();
    quickSort->sort(s3_quick, 100000, false);
    end = high_resolution_clock::now();
    std::cout << "N = 100000: " << duration_cast<milliseconds>(end - start).count() << " ms" << std::endl;

    delete quickSort;

    // Heap Sort
    std::cout << "Heap Sort" << std::endl;
    SortMethod<NIF>* heapSort = new HeapSort<NIF>();

    staticSequence<NIF> s1_heap(sequence1), s2_heap(sequence2), s3_heap(sequence3);
    start = high_resolution_clock::now();
    heapSort->sort(s1_heap, 100, false);
    end = high_resolution_clock::now();
    std::cout << "N = 100: " << duration_cast<milliseconds>(end - start).count() << " ms" << std::endl;

    start = high_resolution_clock::now();
    heapSort->sort(s2_heap, 10000, false);
    end = high_resolution_clock::now();
    std::cout << "N = 10000: " << duration_cast<milliseconds>(end - start).count() << " ms" << std::endl;

    start = high_resolution_clock::now();
    heapSort->sort(s3_heap, 100000, false);
    end = high_resolution_clock::now();
    std::cout << "N = 100000: " << duration_cast<milliseconds>(end - start).count() << " ms" << std::endl;

    delete heapSort;

    // Shell Sort
    std::cout << "Shell Sort" << std::endl;
    SortMethod<NIF>* shellSort = new ShellSort<NIF>(0.5);

    staticSequence<NIF> s1_shell(sequence1), s2_shell(sequence2), s3_shell(sequence3);
    start = high_resolution_clock::now();
    shellSort->sort(s1_shell, 100, false);
    end = high_resolution_clock::now();
    std::cout << "N = 100: " << duration_cast<milliseconds>(end - start).count() << " ms" << std::endl;

    start = high_resolution_clock::now();
    shellSort->sort(s2_shell, 10000, false);
    end = high_resolution_clock::now();
    std::cout << "N = 10000: " << duration_cast<milliseconds>(end - start).count() << " ms" << std::endl;

    start = high_resolution_clock::now();
    shellSort->sort(s3_shell, 100000, false);
    end = high_resolution_clock::now();
    std::cout << "N = 100000: " << duration_cast<milliseconds>(end - start).count() << " ms" << std::endl;

    delete shellSort;

    return 0;
}

#ifndef SORTMETHOD_H
#define SORTMETHOD_H

#include "includes.h"
#include "Sequence.h"

template <class Key>
class SortMethod {
  public:
    virtual void sort(staticSequence<Key>& sequence, int size, bool trace) = 0;
    virtual ~SortMethod() {}
};

// Insertion Sort
template <class Key>
class InsertionSort : public SortMethod<Key> {
  public:
    void sort(staticSequence<Key>& sequence, int size, bool trace) override {
        for (int i = 1; i < size; ++i) {
            Key key = sequence[i];
            int j = i - 1;
            while (j >= 0 && sequence[j] > key) {
                sequence[j + 1] = sequence[j];
                --j;
            }
            sequence[j + 1] = key;
            if (trace) {
                std::cout << "Iteración " << i << ": ";
                sequence.print();
            }
        }
    }
};

// Shake Sort
template <class Key>
class ShakeSort : public SortMethod<Key> {
  public:
    void sort(staticSequence<Key>& sequence, int size, bool trace) override {
        int ini = 1;
        int fin = size - 1;
        int cam = size - 1;
        int iter = 0;

        while (ini < fin) {
            for (int j = fin; j >= ini; --j) {
                if (sequence[j] < sequence[j - 1]) {
                    std::swap(sequence[j], sequence[j - 1]);
                    cam = j;
                }
            }
            ini = cam + 1;
            if (trace) {
                std::cout << "Iteración " << ++iter << " (pasada izquierda a derecha): ";
                sequence.print();
            }

            for (int j = ini; j <= fin; ++j) {
                if (sequence[j] < sequence[j - 1]) {
                    std::swap(sequence[j], sequence[j - 1]);
                    cam = j;
                }
            }
            fin = cam - 1;
            if (trace) {
                std::cout << "Iteración " << ++iter << " (pasada derecha a izquierda): ";
                sequence.print();
            }
        }
    }
};

// Quick Sort (versión clásica adaptada)
template <class Key>
class QuickSort : public SortMethod<Key> {
  public:
    void sort(staticSequence<Key>& sequence, int size, bool trace) override {
        Qsort(sequence, 0, size - 1, trace);
    }

  private:
    void Qsort(staticSequence<Key>& sec, int ini, int fin, bool trace) {
        int i = ini;
        int f = fin;
        Key p = sec[(i + f) / 2];

        while (i <= f) {
            while (sec[i] < p) ++i;
            while (sec[f] > p) --f;
            if (i <= f) {
                std::swap(sec[i], sec[f]);
                if (trace) {
                    std::cout << "Intercambio (i=" << i << ", f=" << f << ", pivote=" << p << "): ";
                    sec.print();
                }
                ++i;
                --f;
            }
        }

        if (ini < f) Qsort(sec, ini, f, trace);
        if (i < fin) Qsort(sec, i, fin, trace);
    }
};


/// Heap Sort (versión clásica adaptada, base 0)
template <class Key>
class HeapSort : public SortMethod<Key> {
  public:
    void sort(staticSequence<Key>& sequence, int size, bool trace) override {
        // Construcción del heap
        for (int i = size / 2 - 1; i >= 0; --i)
            baja(i, sequence, size, trace);

        // Extracción de elementos del heap
        for (int i = size - 1; i > 0; --i) {
            std::swap(sequence[0], sequence[i]);
            if (trace) {
                std::cout << "Swap raíz con índice " << i << ": ";
                sequence.print();
            }
            baja(0, sequence, i, trace);
        }
    }

  private:
    void baja(int i, staticSequence<Key>& sec, int n, bool trace) {
        while (2 * i + 1 < n) {
            int h1 = 2 * i + 1;
            int h2 = h1 + 1;
            int h;

            if (h1 == n - 1) {
                h = h1;
            } else if (sec[h1] > sec[h2]) {
                h = h1;
            } else {
                h = h2;
            }

            if (sec[h] <= sec[i])
                break;
            else {
                std::swap(sec[i], sec[h]);
                if (trace) {
                    std::cout << "Baja (i=" << i << " -> h=" << h << "): ";
                    sec.print();
                }
                i = h;
            }
        }
    }
};


// Shell Sort
template <class Key>
class ShellSort : public SortMethod<Key> {
  public:
    ShellSort(float alpha = 0.5) : alpha_(alpha) {}

    void sort(staticSequence<Key>& sec, int n, bool trace) override {
        int delta = n;
        int iter = 0;

        while ((delta = static_cast<int>(delta * alpha_)) > 0) {
            deltasort(delta, sec, n, trace, iter);
        }
    }

  private:
    float alpha_;

    void deltasort(int delta, staticSequence<Key>& sec, int n, bool trace, int& iter) {
        for (int i = delta; i < n; i++) {
            Key x = sec[i];
            int j = i;
            while (j >= delta && x < sec[j - delta]) {
                sec[j] = sec[j - delta];
                j -= delta;
            }
            sec[j] = x;

            if (trace) {
                std::cout << "Iteración " << ++iter << " (delta=" << delta << "): ";
                sec.print();
            }
        }
    }
};

#endif // SORTMETHOD_H

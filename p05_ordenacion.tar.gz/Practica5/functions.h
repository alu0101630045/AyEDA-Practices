#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include "includes.h"
#include "Sequence.h"
#include "SortMethod.h"
#include "NIF.h"

struct program_options {
  unsigned size;  // Tamaño de la secuencia
  unsigned ordMethod;  // Método de ordenación
  std::string initType;  // Tipo de inicialización: manual, random, file
  std::string fileName;  // Nombre del archivo si la inicialización es desde un archivo
  bool trace;  // Si se muestra la traza
};

void Usage() {
  std::cout << "Usage: ./SortingProgram -size <s> -ord <m> -init <i> [f] -trace <y|n>\n";
  std::cout << "-size <s> : tamaño de la secuencia\n";
  std::cout << "-ord <m> : código del método de ordenación -> 1: Inserción, 2: Sacudida, 3: QuickSort, 4: HeapSort, 5: ShellSort\n";
  std::cout << "-init <i> : tipo de inicialización -> manual, random, file\n";
  std::cout << "-trace <y|n> : si muestra la traza de la ejecución\n";
}

std::optional<program_options> parse_args(int argc, const char *const argv[]) {
  program_options options;
  std::vector<std::string> args(argv + 1, argv + argc);
  if (args.empty()) {
    return std::nullopt;
  }

  for (auto it = args.begin(); it != args.end(); ++it) {
    if (*it == "-size") {
      if (it + 1 >= args.end()) {
        return std::nullopt;
      }
      options.size = std::stoi(*(it + 1));
      it += 1;
    }
    else if (*it == "-ord") {
      if (it + 1 >= args.end()) {
        return std::nullopt;
      }
      options.ordMethod = std::stoi(*(it + 1));
      it += 1;
    }
    else if (*it == "-init") {
      if (it + 1 >= args.end()) {
        return std::nullopt;
      }
      options.initType = *(it + 1);
      if (options.initType == "file" && it + 2 < args.end()) {
        options.fileName = *(it + 2);
        it += 1;
      }
      it += 1;
    }
    else if (*it == "-trace") {
      if (it + 1 >= args.end()) {
        return std::nullopt;
      }
      options.trace = (*(it + 1) == "y");
      it += 1;
    }
  }
  return options;
}

template <class Key>
void execute_sorting(const program_options& options) {
  // Crear la secuencia de tamaño `options.size`
  staticSequence<Key> sequence(options.size);

  // Inicialización de la secuencia según el tipo `options.initType`
  if (options.initType == "manual") {
    // Aquí tendríamos que agregar un método para llenar la secuencia manualmente
  } else if (options.initType == "random") {
    // Llenar la secuencia con valores aleatorios
    sequence.fill_random();
  } else if (options.initType == "file") {
    // Leer datos desde el archivo `options.fileName`
    sequence.fill_from_file(options.fileName);
  }

  // Seleccionar el método de ordenación según `options.ordMethod`
  SortMethod<Key>* sortMethod = nullptr;
  switch (options.ordMethod) {
    case 1:
      sortMethod = new InsertionSort<Key>(&sequence);
      break;
    case 2:
      sortMethod = new ShakeSort<Key>(&sequence);
      break;
    case 3:
      sortMethod = new QuickSort<Key>(&sequence);
      break;
    case 4:
      sortMethod = new HeapSort<Key>(&sequence);
      break;
    case 5:
      sortMethod = new ShellSort<Key>(&sequence);
      break;
    default:
      Usage();
      exit(1);
  }

  // Realizar el ordenamiento y mostrar la traza si `options.trace` es verdadero
  if (options.trace) {
    sortMethod->Sort();
    sequence.print();
  } else {
    sortMethod->Sort();
  }

  delete sortMethod;
}

#endif

#ifndef __SEQUENCE_H__
#define __SEQUENCE_H__

#include "includes.h"

// Abstract base class for sequences
template <class Key>
class Sequence {
public:
  virtual bool search(const Key &k) const = 0;
  virtual bool insert(const Key &k) = 0;
  virtual ~Sequence() {}
  virtual void print() = 0;
  virtual Key operator[](const unsigned) const = 0;
  virtual Key& operator[](const unsigned) = 0;
};

// Static sequence for closed addressing
template <class Key>
class staticSequence : public Sequence<Key> {
public:
  staticSequence(unsigned size);
  bool search(const Key &k) const override;
  bool insert(const Key &k) override;
  bool isFull() const;
  void print() override;
  void fill_random(int n);
  void fill_from_file(std::string filename);
  // Operadores para acceso de lectura y escritura
  Key operator[](const unsigned) const override;
  Key& operator[](const unsigned);

private:
  std::vector<Key> data;
  unsigned blockSize;
};

// Implementación de staticSequence
template <class Key>
staticSequence<Key>::staticSequence(unsigned size) : blockSize(size) {
  data.reserve(blockSize);
}

template <class Key>
bool staticSequence<Key>::search(const Key &k) const {
  for (const auto &key : data) {
    if (key == k) {
      return true;
    }
  }
  return false;
}

template <class Key>
bool staticSequence<Key>::insert(const Key &k) {
  if (data.size() < blockSize && !search(k)) {
    data.push_back(k);
    return true;
  }
  return false;
}

template <class Key>
bool staticSequence<Key>::isFull() const {
  return data.size() >= blockSize;
}

template <class Key>
void staticSequence<Key>::print() {
  for (const auto &key : data) {
    std::cout << key << " ";
  }
  std::cout << std::endl;
}

template <class Key>
Key staticSequence<Key>::operator[](const unsigned i) const {
  return data[i];
}

template <class Key>
Key& staticSequence<Key>::operator[](const unsigned i) {
  return data[i];
}

template <class Key>
void staticSequence<Key>::fill_random(int n) {
  for (int i = 0; i < n; ++i) {
      insert(Key());
  }
}

template <class Key>
void staticSequence<Key>::fill_from_file(std::string filename) {
  std::ifstream fichero(filename);
  if (!fichero.is_open()) {
    std::cerr << "Error al abrir el archivo: " << filename << std::endl;
    return;
  }
  Key k;
  while (fichero >> k) {
    insert(k);
  }
  fichero.close();
}

#endif
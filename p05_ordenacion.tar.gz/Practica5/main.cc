#include "functions.h"

int main(int argc, const char *const argv[]) {
    // Parsear los argumentos de línea de comandos
    auto options = parse_args(argc, argv);

    // Si no se reciben argumentos válidos, mostrar el uso y salir
    if (!options.has_value()) {
        Usage();
        return 1;
    }

    // Crear la secuencia de tamaño `options->size`
    staticSequence<NIF> sequence(options->size);

    // Inicialización de la secuencia según el tipo `options->initType`
    if (options->initType == "manual") {
        std::cout << "Introduzca " << options->size << " valores manualmente (NIF):" << std::endl;
        for (int i = 0; i < options->size; ++i) {
            NIF nuevoNIF; 
            std::cout << "NIF[" << i << "]: ";
            std::cin >> nuevoNIF; 
            sequence.insert(nuevoNIF);
        }
    } else if (options->initType == "random") {
        // Llenar la secuencia con valores aleatorios
        sequence.fill_random(options->size);
    } else if (options->initType == "file") {
        // Leer datos desde el archivo `options->fileName`
        if (!options->fileName.empty()) {
            sequence.fill_from_file(options->fileName);
        } else {
            std::cout << "Se requiere el nombre del archivo para la inicialización desde archivo." << std::endl;
            Usage();
            return 1;
        }
    } else {
        std::cout << "Tipo de inicialización no reconocido. Elija 'manual', 'random' o 'file'." << std::endl;
        return 1;
    }

    // Seleccionar el método de ordenación basado en `options->ordMethod`
    SortMethod<NIF>* sortMethod = nullptr;

    switch (options->ordMethod) {
        case 1:
            sortMethod = new InsertionSort<NIF>();
            break;
        case 2:
            sortMethod = new ShakeSort<NIF>();
            break;
        case 3:
            sortMethod = new QuickSort<NIF>();
            break;
        case 4:
            sortMethod = new HeapSort<NIF>();
            break;
        case 5:
            std::cout << "Introduzca el valor de alpha para ShellSort (0 < alpha < 1): ";
            float alpha;
            std::cin >> alpha;
            if (alpha <= 0 || alpha >= 1) {
                std::cout << "Valor de alpha no válido. Debe estar entre 0 y 1." << std::endl;
                return 1;
            }
            sortMethod = new ShellSort<NIF>(alpha);
            break;
        default:
            Usage();
            return 1;
    }
    
    // Mostrar la secuencia inicial si se desea ver la traza
    std::cout << "Secuencia antes de ordenar: ";
    sequence.print();

    // Realizar el ordenamiento
    sortMethod->sort(sequence, options->size, options->trace);

    // Mostrar la secuencia después de ordenar si se desea ver la traza
    std::cout << "Secuencia después de ordenar: ";
    sequence.print();

    // Limpiar la memoria del objeto de ordenación
    delete sortMethod;

    return 0;
}

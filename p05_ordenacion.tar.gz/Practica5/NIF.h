#ifndef NIF_H
#define NIF_H

#include "includes.h"

class NIF {
public:
  NIF();
  NIF(long val);
  bool operator==(const NIF &other) const;
  bool operator!=(const NIF &other) const;
  operator long() const;
  long getValue() const;
  friend std::istream &operator>>(std::istream &is, NIF &nif);
  friend std::ostream &operator<<(std::ostream &os, const NIF &nif);
private:
  long value_;
};

NIF::NIF() : value_(10000000 + rand() % 90000000) {}  // Genera siempre un número de 8 cifras

NIF::NIF(long val) : value_(val) {}

bool NIF::operator==(const NIF &other) const {
  return value_ == other.value_;
}

bool NIF::operator!=(const NIF &other) const {
  return !(value_ == other.value_);
}

NIF::operator long() const {
  return value_;
}

long NIF::getValue() const {
  return value_;
}

std::istream &operator>>(std::istream &is, NIF &nif) {
  is >> nif.value_;
  return is;
}

std::ostream &operator<<(std::ostream &os, const NIF &nif) {
  os << nif.value_;
  return os;
}

#endif

#ifndef BIGCOMPLEX_H
#define BIGCOMPLEX_H

#include "BigInteger.h"

template <unsigned char Base>
class BigComplex : public BigNumber<Base> {
  public:
	// Constructor por parámetros
	BigComplex(BigInteger<Base> real, BigInteger<Base> imag) : real_(real), imag_(imag) {}

	// Constructor por defecto
	BigComplex() = default;

	// Constructor de copia
	BigComplex(const BigComplex<Base>& complex_param);

	// Sobrecarga de operadores
	template <unsigned char B>
	friend std::ostream& operator<<(std::ostream& os, const BigComplex& complex_param);
	template <unsigned char B>
	friend BigComplex operator+(const BigComplex& complex_param1, const BigComplex& complex_param2);

	// Getters
	BigInteger<Base> real() const { return real_; }
	BigInteger<Base> imag() const { return imag_; }

  // Métodos virtuales puros para las operaciones aritméticas
  virtual BigNumber<Base>* subtract(const BigNumber<Base>&) const override;
  virtual BigNumber<Base>* add(const BigNumber<Base>&) const override;
  virtual BigNumber<Base>* multiply(const BigNumber<Base>&) const override;
  virtual BigNumber<Base>* divide(const BigNumber<Base>&) const override;
	
  // Conversión a otros tipos
  virtual operator BigUnsigned<Base>() const override {
		return this->real().GetNumber();
	}
  virtual operator BigInteger<Base>() const override {
		return this->real();
	}
  virtual operator BigRational<Base>() const override {
		return BigRational<Base>(this->real(), BigUnsigned<Base>(1));
	}
  virtual operator BigComplex<Base>() const override {
		return *this;
	}
	
  // Métodos de entrada/salida
  virtual std::ostream& write(std::ostream&) const override;
  virtual std::istream& read(std::istream&);
  private:
		BigInteger<Base> real_;
		BigInteger<Base> imag_;
};

/// @brief Constructor de copia
/// @param complex_param 
template <unsigned char Base>
BigComplex<Base>::BigComplex(const BigComplex<Base>& complex_param) {
	real_ = complex_param.real_;
	imag_ = complex_param.imag_;
}

/// @brief Sobrecarga de operador de inserción
/// @param os 
/// @param complex_param 
/// @return os
template <unsigned char B>
std::ostream& operator<<(std::ostream& os, const BigComplex<B>& complex_param) {
	if (complex_param.imag().GetSigno() == false) 
		os << complex_param.real() << " + " << complex_param.imag() << "i" << std::endl;
	else
		os << complex_param.real() << "  " << complex_param.imag() << "i" << std::endl;
	return os;
}

/// @brief Sobrecarga de operador de suma
/// @param complex_param1 
/// @param complex_param2 
/// @return complex_result
template <unsigned char B>
BigComplex<B> operator+(const BigComplex<B>& complex_param1, const BigComplex<B>& complex_param2) {
	BigInteger real_result = complex_param1.real() + complex_param2.real();
	BigInteger imag_result = complex_param1.imag() + complex_param2.imag();
	return BigComplex(real_result, imag_result);
}



// Métodos virtuales

/// @brief Suma dos numeros de tipo BigNumber
/// @tparam Base 
/// @param other 
/// @return resultado
template <unsigned char Base>
BigNumber<Base>* BigComplex<Base>::add(const BigNumber<Base>& other) const {
	BigComplex<Base> complex = other.operator BigComplex<Base>();
	BigComplex<Base> complex_result = *this + complex;
	return new BigComplex<Base>(complex_result);
}



/// @brief Resta dos numeros de tipo BigNumber 
/// @tparam Base 
/// @param other 
/// @return resultado 
template <unsigned char Base>
BigNumber<Base>* BigComplex<Base>::subtract(const BigNumber<Base>& other) const {

}



/// @brief Multiplica dos numeros de tipo BigNumber
/// @tparam Base 
/// @param other 
/// @return resultado
template <unsigned char Base>
BigNumber<Base>* BigComplex<Base>::multiply(const BigNumber<Base>& other) const {

}



/// @brief Divide dos numeros de tipo BigNumber
/// @tparam Base 
/// @param other 
/// @return resultado
template <unsigned char Base>
BigNumber<Base>* BigComplex<Base>::divide(const BigNumber<Base>& other) const {

}



/// @brief Método para escribir en un flujo de salida
/// @tparam Base 
/// @param os 
/// @return os
template <unsigned char Base>
std::ostream& BigComplex<Base>::write(std::ostream& os) const {
  os << *this << "r";
  return os;
}



/// @brief Método para leer de un flujo de entrada
/// @tparam Base 
/// @param is 
/// @return is
template <unsigned char Base>
std::istream& BigComplex<Base>::read(std::istream& is) {
  return is;
}

#endif
// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Algortimos y Estructuras de Datos Avanzadas
// Curso: 2º
// Práctica 3: Calculadora para números grandes
// Autor: Pablo García de los Reyes
// Correo: alu0101630045@ull.edu.es
// Fecha: 13/03/2025
// Archivo Funciones.h: Fichero de cabecera con funciones auxiliares para garantizar el correcto funcionamiento del programa
// Historial de revisiones
// 09/03/2025 - Creación (primera versión) del código
// 12/03/2025 - Eliminación de la especialización en Base 2 para generalizar los métodos virtuales a todas las bases.

#ifndef FUNCIONES_H
#define FUNCIONES_H

#include "BigRational.h"

#include <sstream>
#include <fstream>

/// @brief Obtener la base del fichero 
/// @param filename 
/// @return 
unsigned char getBase(const std::string filename) {
  // Formato:
  // Base = 16
  // ...
  std::ifstream file(filename);
  if (!file.is_open()) {
    std::cerr << "Error: Could not open file " << filename << std::endl;
    return 0;
  }
  std::string line;
  std::getline(file, line);
  unsigned char base = std::stoi(line.substr(6));
  return base;
}



/// @brief Uso del programa
/// @param argc
/// @param argv
void Usage(int argc, char* argv[]) {
  if (argc != 2) {
    std::cerr << "Usage: " << argv[0] << " <filename>" << std::endl;
    exit(EXIT_FAILURE);
  }
}

#endif
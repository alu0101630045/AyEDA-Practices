// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Algortimos y Estructuras de Datos Avanzadas
// Curso: 2º
// Práctica 3: Calculadora para números grandes
// Autor: Pablo García de los Reyes
// Correo: alu0101630045@ull.edu.es
// Fecha: 13/03/2025
// Archivo BigRational.h: Archivo de cabecera de la clase BigRational
// Contiene la declaración de la clase BigRational, que representa un número racional grande a partir de dos números grandes (BigInteger y BigUnsigned) 
// Historial de revisiones
// 09/03/2025 - Creación (primera versión) del código
// 12/03/2025 - Eliminación de la especialización en Base 2 para generalizar los métodos virtuales a todas las bases.

#ifndef BIGRATIONAL_H
#define BIGRATIONAL_H

#include "BigNumber.h"
#include "BigInteger.h"  // Se necesita porque usa BigInteger

template <unsigned char Base>
class BigRational : public BigNumber<Base> {
 public:
  // Constructores
  BigRational() {};
  BigRational(const BigInteger<Base>&, const BigUnsigned<Base>&);

  // Extracción e insercción
  template <unsigned char B>
  friend std::ostream& operator<<(std::ostream&, const BigRational<B>&);
  template <unsigned char B>
  friend std::istream& operator>>(std::istream&, BigRational<B>&);

  // Comparación
  bool operator==(const BigRational<Base>&) const;

  // SmallerThan
  template <unsigned B>
  friend bool operator<(const BigRational<B>&, const BigRational<B>&);
  
  // Operadores
  BigRational<Base> operator-(const BigRational<Base>&) const;
  BigRational<Base> operator+(const BigRational<Base>&) const;
  BigRational<Base> operator/(const BigRational<Base>&) const;
  BigRational<Base> operator*(const BigRational<Base>&) const;

  // Métodos
  BigRational<Base> Simplificar();
  
  // Getters
  BigInteger<Base> GetNumerador() const { return numerador_; }
  BigUnsigned<Base> GetDenominador() const { return denominador_; }
  BigInteger<Base> GetResult() const;
  
  // Setters
  void SetNumerador(BigInteger<Base> numerador) { numerador_ = numerador; }
  void SetDenominador(BigUnsigned<Base> denominador) { denominador_ = denominador; }

  // Métodos virtuales
  // Implementación de métodos virtuales de BigNumber<Base>
  BigNumber<Base>* add(const BigNumber<Base>&) const override;
  BigNumber<Base>* subtract(const BigNumber<Base>&) const override;
  BigNumber<Base>* multiply(const BigNumber<Base>&) const override;
  BigNumber<Base>* divide(const BigNumber<Base>&) const override;
  // Conversión a otros tipos
  operator BigUnsigned<Base>() const override {
    return this->GetResult().GetNumber();
  }
  operator BigInteger<Base>() const override {
    return this->GetResult();
  }
  operator BigRational<Base>() const override {
    return *this;
  }
  operator BigComplex<Base>() const override {
    return BigComplex<Base>(BigInteger<Base>(this->GetResult()), BigInteger<Base>("0"));
  }
  // Métodos de entrada/salida
  std::ostream& write(std::ostream&) const override;
  std::istream& read(std::istream&) override;  
 private:
  BigInteger<Base> numerador_;
  BigUnsigned<Base> denominador_;
};


/// @brief Constructor de BigRational
/// @tparam Base 
/// @param entero 
/// @param natural 
template <unsigned char Base>
BigRational<Base>::BigRational(const BigInteger<Base>& entero, const BigUnsigned<Base>& natural) {
  numerador_ = entero;
  denominador_ = natural;
}


/// @brief Sobrecarga de operador de inserción 
/// @tparam B 
/// @param in 
/// @param racional 
/// @return in
template <unsigned char B>
std::istream& operator>>(std::istream& in, BigRational<B>& racional) {
  return in;
}



/// @brief Sobrecarga de operador de extracción
/// @tparam B
/// @param os
/// @param num
/// @return os
template <unsigned char B>
std::ostream& operator<<(std::ostream& os, const BigRational<B>& num) {
  BigRational<B> aux = num;
  // if (B != 2) aux.Simplificar();
  os << aux.GetNumerador() << "/" << aux.GetDenominador();
  return os;
}


/// @brief Sobrecarga de operador de igualdad
/// @tparam Base
/// @param num
/// @return true || false
template <unsigned char Base>
bool BigRational<Base>::operator==(const BigRational<Base>& num) const {
  if((this->GetNumerador().GetNumber() == num.GetNumerador().GetNumber())
  && (this->GetNumerador().GetSigno() == num.GetNumerador().GetSigno()) 
  && (this->GetDenominador() == num.GetDenominador())) {
    return true;
  }
  return false;
}



/// @brief Sobrecarga de operador menor que
/// @tparam Base 
/// @param primero 
/// @param segundo 
/// @return true || false 
template <unsigned char Base>
bool operator<(const BigRational<Base>& primero, const BigRational<Base>& segundo) {
    // Convertimos las fracciones a un denominador común
    BigInteger<Base> denominador_comun = primero.GetDenominador() * segundo.GetDenominador();
    BigInteger<Base> numerador_primero = primero.GetNumerador() * segundo.GetDenominador();
    BigInteger<Base> numerador_segundo = segundo.GetNumerador() * primero.GetDenominador();
    
    // Comparamos los numeradores con el mismo denominador común
    if (numerador_primero < numerador_segundo) {
        return true;  // El primero es menor
    } else {
        return false;  // El primero no es menor
    }
}



/// @brief Sobrecarga de operador de resta 
/// @tparam Base 
/// @param num 
/// @return resultado 
template <unsigned char Base>
BigRational<Base> BigRational<Base>::operator-(const BigRational<Base>& num) const {
  // a/b - c/d == ((a*d) - (b*c)) / (b*d)
  BigInteger<Base> a = this->GetNumerador();
  BigInteger<Base> b(this->GetDenominador());
  BigInteger<Base> c = num.GetNumerador();
  BigInteger<Base> d(num.GetDenominador());
  // (a*d)
  BigInteger<Base> primer = a * d;
  // (b*c)
  BigInteger<Base> segundo = b * c;
  // (b*d)
  BigInteger<Base> tercero = b * d;
  BigRational<Base> resultado;
  resultado.SetNumerador((primer - segundo));
  resultado.SetDenominador(tercero.GetNumber());
  return resultado;
}



// Suma
template <unsigned char Base>
BigRational<Base> BigRational<Base>::operator+(const BigRational<Base>& num) const {
  // a/b + c/d == ((a*d) + (b*c)) / (b*d)
  BigInteger<Base> a = this->GetNumerador();
  BigInteger<Base> b(this->GetDenominador());
  BigInteger<Base> c = num.GetNumerador();
  BigInteger<Base> d(num.GetDenominador());
  // (a*d)
  BigInteger<Base> primer = a * d;
  // (b*c)
  BigInteger<Base> segundo = b * c;
  // (b*d)
  BigInteger<Base> tercero = b * d;
  BigRational<Base> resultado;
  resultado.SetNumerador((primer + segundo));
  resultado.SetDenominador(tercero.GetNumber());
  return resultado;
}


// División
template <unsigned char Base>
BigRational<Base> BigRational<Base>::operator/(const BigRational<Base>& num) const {
  // a/b + c/d == (a*d) / (b*c)
  BigInteger<Base> a = this->GetNumerador();
  BigInteger<Base> b(this->GetDenominador());
  BigInteger<Base> c = num.GetNumerador();
  BigInteger<Base> d(num.GetDenominador());
  // (a*d)
  BigInteger<Base> primer = a * d;
  // (b*c)
  BigInteger<Base> segundo = b * c;
  if(primer.GetSigno() != segundo.GetSigno()) {
    primer.SetSigno(false);
    segundo.SetSigno(true);
  }
  else {
    primer.SetSigno(true);
    segundo.SetSigno(true);
  }
  BigRational<Base> resultado;
  resultado.SetNumerador(primer);
  resultado.SetDenominador(segundo.GetNumber());
  return resultado;
}


// Multiplicación
template <unsigned char Base>
BigRational<Base> BigRational<Base>::operator*(const BigRational<Base>& num) const {
  // a/b + c/d == (a*c) / (b*d)
  BigInteger<Base> a = this->GetNumerador();
  BigInteger<Base> b(this->GetDenominador());
  BigInteger<Base> c = num.GetNumerador();
  BigInteger<Base> d(num.GetDenominador());
  // (a*c) 
  BigInteger<Base> primer = a * c;
  // (b*d)
  BigInteger<Base> segundo = b * d;
  BigRational<Base> resultado;
  resultado.SetNumerador(primer);
  resultado.SetDenominador(segundo.GetNumber());
  return resultado;
}


// Solve
template <unsigned char Base>
BigInteger<Base> BigRational<Base>::GetResult() const {
  BigInteger<Base> aux(this->GetNumerador().GetNumber() / this->GetDenominador());
  if(this->GetNumerador().GetSigno() == false) {
    aux.SetSigno(false);
  }
  return aux;
}


// Simplificación
template <unsigned char Base>
BigRational<Base> BigRational<Base>::Simplificar() {
  BigInteger<Base> numerador = this->GetNumerador();
  BigUnsigned<Base> denominador = this->GetDenominador();

  BigUnsigned<Base> dos_aux;
  dos_aux.SetInmediato(2);
  BigInteger<Base> dos(dos_aux);

  BigUnsigned<Base> uno_aux;
  uno_aux.SetInmediato(1);
  BigInteger<Base> uno(uno_aux);


  for(BigInteger<Base> i = dos; i.GetNumber() < numerador.GetNumber(); i = i + uno) {
    while(((numerador.GetNumber() % i.GetNumber()) == denominador.GetZero()) &&
           ((denominador % i.GetNumber()) == denominador.GetZero())) {
      // Si ambos números son divisibles por i, se dividen
      numerador = numerador / i;
      denominador = denominador / i.GetNumber();
    }
  }


  if(numerador.GetNumber() == denominador) {
    denominador.SetInmediato(1);
    if(numerador.GetSigno() == false) {
      uno.SetSigno(false);
      numerador = uno;
    }
    else {
      numerador = uno;
    }
  }
  this->SetNumerador(numerador);
  this->SetDenominador(denominador);
  return *this;
}



//--------------------------------------------------PRACTICA 3------------------------------------------------



/// @brief Suma dos numeros de tipo BigNumber
/// @tparam Base 
/// @param other 
/// @return resultado
template <unsigned char Base>
BigNumber<Base>* BigRational<Base>::add(const BigNumber<Base>& other) const {
    // Convertimos `other` a `BigUnsigned<Base>`
    const BigRational<Base>& num = other.operator BigRational<Base>();

    // Usamos el operador sobrecargado `+` para la suma
    BigRational<Base> resultado = (*this) + num;

    // Devolvemos un puntero a un nuevo objeto `BigUnsigned<Base>`
    return new BigRational<Base>(resultado);
}



/// @brief Resta dos numeros de tipo BigNumber 
/// @tparam Base 
/// @param other 
/// @return resultado 
template <unsigned char Base>
BigNumber<Base>* BigRational<Base>::subtract(const BigNumber<Base>& other) const {
    const BigRational<Base>& num = other.operator BigRational<Base>();
    return new BigRational<Base>((*this) - num);
}



/// @brief Multiplica dos numeros de tipo BigNumber
/// @tparam Base 
/// @param other 
/// @return resultado
template <unsigned char Base>
BigNumber<Base>* BigRational<Base>::multiply(const BigNumber<Base>& other) const {
    const BigRational<Base>& num = other.operator BigRational<Base>();
    return new BigRational<Base>((*this) * num);
}



/// @brief Divide dos numeros de tipo BigNumber
/// @tparam Base 
/// @param other 
/// @return resultado
template <unsigned char Base>
BigNumber<Base>* BigRational<Base>::divide(const BigNumber<Base>& other) const {
    const BigRational<Base>& num = other.operator BigRational<Base>();
    if (num.GetResult() == 0) {
      throw BigNumberDivisionByZero("Error: División por cero no permitida.");
    }
    return new BigRational<Base>((*this) / num);
}



/// @brief Método para escribir en un flujo de salida
/// @tparam Base 
/// @param os 
/// @return os
template <unsigned char Base>
std::ostream& BigRational<Base>::write(std::ostream& os) const {
  os << *this << "r";
  return os;
}



/// @brief Método para leer de un flujo de entrada
/// @tparam Base 
/// @param is 
/// @return is
template <unsigned char Base>
std::istream& BigRational<Base>::read(std::istream& is) {
  return is;
}

#endif
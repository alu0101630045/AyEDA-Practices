// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Algortimos y Estructuras de Datos Avanzadas
// Curso: 2º
// Práctica 3: Calculadora para números grandes
// Autor: Pablo García de los Reyes
// Correo: alu0101630045@ull.edu.es
// Fecha: 13/03/2025
// Archivo BigNumberException.h: Archivo de cabecera de la clase BigNumberException
// Contiene la declaración de la clase BigNumberException, que representa una excepción personalizada para la clase BigNumber 
// Historial de revisiones
// 09/03/2025 - Creación (primera versión) del código
// 12/03/2025 - Eliminación de la especialización en Base 2 para generalizar los métodos virtuales a todas las bases.

#ifndef BIGNUMBEREXCEPCION_H
#define BIGNUMBEREXCEPCION_H

#include <iostream>
#include <exception>

class BigNumberException : public std::exception {
  public:
    BigNumberException(const std::string& message) : message_(message) {}
    const char* what() const noexcept override { return message_.c_str(); }

  private:
    std::string message_;
};

class BigNumberBadDigit : public BigNumberException {
  public:
    BigNumberBadDigit(const std::string& message) : BigNumberException(message) {}
};

class BigNumberDivisionByZero : public BigNumberException {
  public:
    BigNumberDivisionByZero(const std::string& message) : BigNumberException(message) {}
};

class BigNumberInvalidBase : public BigNumberException {
  public:
    BigNumberInvalidBase(const std::string& message) : BigNumberException(message) {}
};

#endif
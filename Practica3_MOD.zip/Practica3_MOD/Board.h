// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Algortimos y Estructuras de Datos Avanzadas
// Curso: 2º
// Práctica 3: Calculadora para números grandes
// Autor: Pablo García de los Reyes
// Correo: alu0101630045@ull.edu.es
// Fecha: 13/03/2025
// Archivo Board.h: Archivo de cabecera de la clase Board
// Contiene la declaración de la clase Board, que representa un tablero de operaciones
// Historial de revisiones
// 09/03/2025 - Creación (primera versión) del código
// 12/03/2025 - Eliminación de la especialización en Base 2 para generalizar los métodos virtuales a todas las bases.

#ifndef BOARD_H
#define BOARD_H

#include "BigNumber.h"
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <stack>

template <unsigned char Base>
class Board {
  public:
  // Constructor por defecto
  Board() {}
  // Destructor
  ~Board() {}
  // Método para añadir un número al tablero
  void addNumber(const std::string& name, BigNumber<Base>* number);
  // Método para obtener un número del tablero
  BigNumber<Base>* getNumber(const std::string& name) const;
  // Método para escribir el tablero en un fichero
  void writeToFile(const std::string& filename) const;
  // Método para leer declaraciones del fichero
  void readNumber(std::string& line);
  // Método para leer operaciones del fichero
  std::vector<std::string> readOperation(std::string& line);
  // Método para leer el tablero de un fichero
  void operateFromFile(const std::string& filename);
  // Método para realizar las operaciones
  std::stack<BigNumber<Base>*> evaluateOperations(std::vector<std::string> operation, std::stack<BigNumber<Base>*> rpn_stack);
  // Método para mostrar el tablero por pantalla
  void print() const;
  private:
    std::vector<std::pair<std::string, BigNumber<Base>*>> board;
};



/// @brief Añade un nuevo número al tablero
/// @tparam Base 
/// @param name 
/// @param number 
template <unsigned char Base>
void Board<Base>::addNumber(const std::string& name, BigNumber<Base>* number) {
    for (auto& pair : board) {
        if (pair.first == name) {
            pair.second = number;  // Actualizar el valor si ya existe
            return;
        }
    }
    board.push_back(std::make_pair(name, number));  // Si no existe, agregarlo
}



/// @brief Obtiene un número del tablero
/// @tparam Base
/// @param name
/// @return BigNumber<Base>*
template <unsigned char Base>
BigNumber<Base>* Board<Base>::getNumber(const std::string& name) const {
  for (const auto& pair : board) {
    if (pair.first == name) {
      return pair.second;
    }
  }
  return nullptr;
}
                                                 


/// @brief Escribe el tablero en un fichero
/// @tparam Base
/// @param filename
template <unsigned char Base>
void Board<Base>::writeToFile(const std::string& filename) const {
  std::ofstream file(filename);
  if (file.is_open()) {
    for (const auto& pair : board) {
      file << pair.first << " = " << *pair.second << std::endl;
    }
    file.close();
  }
  else {
    std::cerr << "Error: Unable to open file " << filename << std::endl;
  }
}



/// @brief Lee declaraciones del fichero
/// @tparam Base
/// @param file
template <unsigned char Base>
void Board<Base>::readNumber(std::string& line) {
  std::istringstream iss(line);
  std::string name;
  std::string equal;
  std::string number;
  iss >> name >> equal >> number;
  BigNumber<Base>* bn = create<Base>(number.c_str());
  addNumber(name, bn);
}



/// @brief Lee operaciones del fichero
/// @tparam Base
/// @param file
template <unsigned char Base>
std::vector<std::string> Board<Base>::readOperation(std::string& line) {
    std::istringstream iss(line);
    std::string token;
    std::vector<std::string> operation;

    while (iss >> token) {
        operation.push_back(token);
    }

    return operation;
}



/// @brief Lee el tablero de un fichero
/// @tparam Base
/// @param filename
template <unsigned char Base>
void Board<Base>::operateFromFile(const std::string& filename) {
  // Base = 16
  // N1 = 2361i
  // N2 = AB64u
  // E1 ? N2 N1 +
  std::ifstream file(filename);
  std::stack<BigNumber<Base>*> rpn_stack;
  if (file.is_open()) {
    std::string line;
    std::getline(file, line);
    unsigned char base = std::stoi(line.substr(6));
    while (std::getline(file, line)) {
      std::istringstream iss(line);
      std::string first_word, second_word;
      iss >> first_word >> second_word;
      if (second_word == "?") {
      std::vector<std::string> operation = readOperation(line);
      rpn_stack = evaluateOperations(operation, rpn_stack);
      } 
      else {
      readNumber(line);
      }
    }
    file.close();
  }
  else {
    std::cerr << "Error: Unable to open file " << filename << std::endl;
  }
}



/// @brief Realiza las operaciones
/// @tparam Base
/// @param N1
/// @param N2
/// @param op
/// @param rpn_stack
/// @return std::stack<BigNumber<Base>*>
template <unsigned char Base>
std::stack<BigNumber<Base>*> Board<Base>::evaluateOperations(
    std::vector<std::string> operation, std::stack<BigNumber<Base>*> rpn_stack) {
    std::string result_name = operation[0];  // Nombre del resultado (Ej: "E1")
    operation.erase(operation.begin(), operation.begin() + 2);  // Eliminar "E1 ?"
    for (const std::string& token : operation) {
        BigNumber<Base>* number = getNumber(token);
        // Si el token es un número, lo añadimos a la pila
        if (number) {  
            rpn_stack.push(number);
        }
        else if (token == "+" || token == "-" || token == "*" || token == "/") {
            if (rpn_stack.size() < 2) {
                std::cerr << "Error: No hay suficientes operandos para " << token << std::endl;
                return rpn_stack;
            }
            BigNumber<Base>* b = rpn_stack.top(); rpn_stack.pop();
            BigNumber<Base>* a = rpn_stack.top(); rpn_stack.pop();
            BigNumber<Base>* result = nullptr;
            // Depuración
            //std::cout << "a: " << *a << std::endl;
            //std::cout << "b: " << *b << std::endl;
            //std::cout << "token: " << token << std::endl;
            try {
                if (token == "+") result = a->add(*b);
                else if (token == "-") result = a->subtract(*b);
                else if (token == "*") result = a->multiply(*b);
                else if (token == "/") result = a->divide(*b);
            } catch (const std::exception& e) {
                std::cerr << "Error en operación: " << e.what() << std::endl;
            }
            // Depuracion
            // std::cout << "result: " << *result << std::endl;
            rpn_stack.push(result);
        }
        else {
            std::cerr << "Error: Token desconocido '" << token << "'" << std::endl;
            return rpn_stack;
        }
    }
    // Ahora extraemos el resultado final de la pila correctamente
    if (!rpn_stack.empty()) {
        BigNumber<Base>* final_result = rpn_stack.top();
        rpn_stack.pop();  // Removerlo de la pila antes de guardarlo en `Board`
        addNumber(result_name, final_result);  // Guardar resultado en `Board`
    } 
    else {
        std::cerr << "Error: Expresión RPN inválida." << std::endl;
    }
    return rpn_stack;
}



/// @brief Muestra el tablero por pantalla
/// @tparam Base
template <unsigned char Base>
void Board<Base>::print() const {
  for (const auto& pair : board) {
    std::cout << pair.first << " = " << *pair.second << std::endl;
  }
}

#endif
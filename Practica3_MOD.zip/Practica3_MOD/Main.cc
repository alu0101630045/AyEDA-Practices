// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Algortimos y Estructuras de Datos Avanzadas
// Curso: 2º
// Práctica 3: Calculadora para números grandes
// Autor: Pablo García de los Reyes
// Correo: alu0101630045@ull.edu.es
// Fecha: 13/03/2025
// Archivo Main.cc: Función principal del programa
// Historial de revisiones
// 09/03/2025 - Creación (primera versión) del código
// 12/03/2025 - Eliminación de la especialización en Base 2 para generalizar los métodos virtuales a todas las bases.

#include "BigRational.h"
#include "Board.h"
#include "Funciones.h"
#include "BigComplex.h"

int main(int argc, char* argv[]) {
  // Probar operaciones BigComplex
  BigNumber<10>* c1 = new BigComplex<10>(BigInteger<10>(1), BigInteger<10>(2));
  BigNumber<10>* c2 = new BigInteger<10>(3);
  BigNumber<10>* c3 = c2->add(*c1); // 4 + 2i
  std::cout << *c3 << std::endl; 

  // Comprobar número de argumentos
  Usage(argc, argv);
  // Crear un tablero
  const unsigned char base = getBase(argv[1]);
  if (base == 10) {
    Board<10> board;
    board.operateFromFile(argv[1]);
    board.print();
    board.writeToFile("output.txt");
  }
  else if (base == 2) {
    Board<2> board;
    board.operateFromFile(argv[1]);
    board.print();
    board.writeToFile("output.txt");
  }
  else if (base == 16) {
    Board<16> board;
    board.operateFromFile(argv[1]);
    board.print();
    board.writeToFile("output.txt");
  }
  else if (base == 8) {
    Board<8> board;
    board.operateFromFile(argv[1]);
    board.print();
    board.writeToFile("output.txt");
  }
  else {
    throw BigNumberInvalidBase("Excepción: Base no válida");
  }
  return 0;
}
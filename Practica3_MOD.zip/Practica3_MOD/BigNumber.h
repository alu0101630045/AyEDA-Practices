#ifndef BIGNUMBER_H
#define BIGNUMBER_H

#include <iostream>
#include <string>

// Forward Declarations para evitar dependencias circulares
template <unsigned char Base> class BigUnsigned;
template <unsigned char Base> class BigInteger;
template <unsigned char Base> class BigRational;
template <unsigned char Base> class BigComplex;


template <unsigned char Base>
class BigNumber {
 public:
  // Destructor virtual
  virtual ~BigNumber() {}  

  // Métodos virtuales puros para las operaciones aritméticas
  virtual BigNumber<Base>* add(const BigNumber<Base>&) const = 0;
  virtual BigNumber<Base>* subtract(const BigNumber<Base>&) const = 0;
  virtual BigNumber<Base>* multiply(const BigNumber<Base>&) const = 0;
  virtual BigNumber<Base>* divide(const BigNumber<Base>&) const = 0;

  // Conversión a otros tipos
  virtual operator BigUnsigned<Base>() const = 0;
  virtual operator BigInteger<Base>() const = 0;
  virtual operator BigRational<Base>() const = 0;
  virtual operator BigComplex<Base>() const = 0;

  // Métodos de entrada/salida
  virtual std::ostream& write(std::ostream&) const = 0;
  virtual std::istream& read(std::istream&) = 0;

  // Método create
  static BigNumber<Base>* create(const char* str);

  // Definición de operadores de flujo
  friend std::ostream& operator<<(std::ostream& os, const BigNumber<Base>& bn) {
    return bn.write(os);
  }

  friend std::istream& operator>>(std::istream& is, BigNumber<Base>& bn) {
    return bn.read(is);
  }
};



/// @brief Método create
/// @tparam Base 
/// @param str 
/// @return 
template <unsigned char Base>
static BigNumber<Base>* create(const char* str) {
  std::string input(str);
  size_t length = input.length();
  // Verificamos el sufijo para determinar el tipo
  if(length > 1) {
    char suffix = input[length - 1]; // Último carácter
    if(suffix == 'u') {
      // Crear un BigUnsigned
      return new BigUnsigned<Base>(input.substr(0, length - 1).c_str());;
    }
    else if(suffix == 'i') {
      // Crear un BigInteger
      return new BigInteger<Base>(input.substr(0, length - 1).c_str());;
    }
    else if(suffix == 'r') {
      // Procesar el caso BigRational
      size_t slash_pos = input.find('/');
        
      if(slash_pos != std::string::npos) {  // npos para comfirmar si hay /
        // Separar en numerador y denominador
        std::string num_str = input.substr(0, slash_pos);
        std::string denom_str = input.substr(slash_pos + 1, length - slash_pos - 2); // -2 para quitar 'r'
        
        BigInteger<Base> numerador(num_str.c_str());
        BigUnsigned<Base> denominador(denom_str.c_str());
        // Crear y retornar el BigRational
        BigRational<Base> rat(numerador, denominador);
        return new BigRational<Base>(numerador, denominador);;
      }
    }
    else if(suffix == 'c') {
      // Formato de entrada: 123 + 123ic
      // NO FUNCIONA
      std::istringstream ss(input);
      std::string real_str, imag_str, plus;
      // ss >> real_str;
      // ss >> plus;
      // ss >> imag_str;
      // Crear y retornar el BigComplex
      BigInteger<Base> real(real_str.c_str());
      BigInteger<Base> imag(imag_str.substr(0, imag_str.length() - 2).c_str());
      BigComplex<Base> comp(real, imag);
      return new BigComplex<Base>(real, imag);
    }
  }
  // Si no se encuentra un sufijo válido, lanzamos una excepción o retornamos nullptr
  std::cerr << "Error: Invalid type suffix in input string." << std::endl;
  return nullptr;
}


#endif // BIGNUMBER_H
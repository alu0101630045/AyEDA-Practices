#ifndef BIGINTEGER_H
#define BIGINTEGER_H

#include "BigNumber.h"
#include "BigUnsigned.h"  // Se necesita porque usa BigUnsigned
#include "BigRational.h"

template <unsigned char Base>
class BigInteger : public BigNumber<Base> {
  public:
    // Constructores
    BigInteger(int n = 0);
    BigInteger(const BigUnsigned<Base>&);
    BigInteger(const BigInteger<Base>&); // Constructor de copia
    BigInteger(std::string str);

    // Sobrecarga de operadores
    BigInteger<Base>& operator=(const BigInteger<Base>& number_param);

    // Inserción/Extracción
    template <unsigned char B>
    friend std::ostream& operator<<(std::ostream& os, const BigInteger<B>& number_param);
    template <unsigned char B>
    friend std::istream& operator>>(std::istream& is, BigInteger<B>& number_param);
    
    // Comparación
    bool operator==(const BigInteger<Base>& number_param) const;
    template <unsigned char B>
    friend bool operator<(const BigInteger<B>& number_param1, const BigInteger<B>& number_param2);
    
    // Incremento/Decremento
    BigInteger<Base>& operator++(); // Pre-incremento
    BigInteger<Base> operator++(int); // Post-incremento
    BigInteger<Base>& operator--(); // Pre-decremento
    BigInteger<Base> operator--(int); // Post-decremento
    
    // Operadores aritméticos
    template <unsigned char B>
    friend BigInteger<B> operator+(const BigInteger<B>&, const BigInteger<B>&);
    BigInteger<Base> operator-(const BigInteger<Base>&) const;
    BigInteger<Base> operator*(const BigInteger<Base>&) const;
    template <unsigned char B>
    friend BigInteger<B> operator/(const BigInteger<B>&, const BigInteger<B>&);
    BigInteger<Base> operator%(const BigInteger<Base>&) const;
    
    // Métodos extra
    BigInteger<Base> mcd(BigInteger<Base> a, BigInteger<Base> b);
    bool isZero();
    
    // Getter
    BigUnsigned<Base> GetNumber() const { return number_; }
    bool GetSigno() const { return sign_; }
    BigUnsigned<Base> GetZero() const { return BigUnsigned<Base>((const unsigned char*)"0"); }
    
    // Setter
    void SetInmediato(int n) { number_ = BigUnsigned<Base>(n); }
    void SetSigno(bool signo) { sign_ = signo; }

    // Métodos virtuales
    BigNumber<Base>* add(const BigNumber<Base>&) const override;
    BigNumber<Base>* subtract(const BigNumber<Base>&) const override;
    BigNumber<Base>* multiply(const BigNumber<Base>&) const override;
    BigNumber<Base>* divide(const BigNumber<Base>&) const override;
    
    // Conversión a otros tipos
    operator BigInteger<Base>() const override {
      return *this;
    }
    
    operator BigRational<Base>() const override {
      return BigRational<Base>(BigInteger<Base>(*this), BigUnsigned<Base>(1));
    }
    operator BigUnsigned<Base>() const override {
      return BigUnsigned<Base>(this->GetNumber());
    }
    operator BigComplex<Base>() const override {
      // Devolver el BigInteger como parte real y 0 como parte imaginaria
      return BigComplex<Base>(BigInteger<Base>(*this), BigInteger<Base>(0));
    }    
    // Métodos de entrada/salida
    std::ostream& write(std::ostream&) const override;
    std::istream& read(std::istream&) override;
  private:
    BigUnsigned<Base> number_;
    bool sign_; // true si es negativo, false si es positivo
};



/// @brief Constructor a partir de un número entero
/// @param n
template <unsigned char Base>
BigInteger<Base>::BigInteger(int n) {
  if (n == 0) {
    number_ = BigUnsigned<Base>(n = 0);
    sign_ = false;
  }
  else {
    if (n < 0) {
      sign_ = true;
      n = -n;
    }
    else {
      sign_ = false;
    }
    number_ = BigUnsigned<Base>(n);
  }
}



/// @brief Constructor a partir de un BigUnsigned
/// @param number_param
template <unsigned char Base>
BigInteger<Base>::BigInteger(const BigUnsigned<Base>& number_param) {
  number_ = number_param;
  sign_ = false;
}



/// @brief Constructor de copia
/// @param copy
template <unsigned char Base>
BigInteger<Base>::BigInteger(const BigInteger<Base>& copy) : number_(copy.number_), sign_(copy.sign_) {}



/// @brief Sobrecarga de operador de copia
/// @param number_param
/// @return number_result
template <unsigned char Base>
BigInteger<Base>& BigInteger<Base>::operator=(const BigInteger<Base>& number_param) {
  if (this != &number_param) {
    number_ = number_param.number_;
    sign_ = number_param.sign_;
  }
  return *this;
}



/// @brief Constructor a partir de un string
/// @tparam Base 
/// @param str 
template <unsigned char Base>
BigInteger<Base>::BigInteger(std::string str) {
  if (str[0] == '-') {
    sign_ = true;
    str = str.substr(1);
  }
  else {
    sign_ = false;
  }
  number_ = BigUnsigned<Base>((const unsigned char*)str.c_str());
}



/// @brief Sobrecarga de operador de inserción
/// @param os
/// @param number_param
/// @return os
template <unsigned char B>
std::ostream& operator<<(std::ostream& os, const BigInteger<B>& number_param) {
  if (number_param.sign_) {
    os << "-";
  }
  os << number_param.number_;
  return os;
}



/// @brief Sobrecarga de operador de extracción
/// @param is
/// @param number_param
/// @return is
template <unsigned char B>
std::istream& operator>>(std::istream& is, BigInteger<B>& number_param) {
  int user_number;
  is >> user_number;
  if (user_number < 0) {
    number_param.sign_ = true;
    user_number = -user_number;
  }
  else {
    number_param.sign_ = false;
  }
  number_param.number_ = BigUnsigned(user_number);
  return is;
}



/// @brief
/// @param number_param
/// @return
template <unsigned char Base>
bool BigInteger<Base>::operator==(const BigInteger<Base>& number_param) const {
  return (sign_ == number_param.sign_) && (number_ == number_param.number_);
}



/// @brief
/// @param number_param1
/// @param number_param2
/// @return
template <unsigned char Base>
bool operator<(const BigInteger<Base>& number_param1, const BigInteger<Base>& number_param2) {
  if (number_param1.sign_ && !number_param2.sign_) {
    return true;
  }
  else if (!number_param1.sign_ && number_param2.sign_) {
    return false;
  }
  else if (number_param1.sign_ && number_param2.sign_) {
    return number_param2.number_ < number_param1.number_;
  }
  else {
    return number_param1.number_ < number_param2.number_;
  }
}



/// @brief
/// @return
template <unsigned char Base>
BigInteger<Base>& BigInteger<Base>::operator++() {
  *this = *this + 1;
  return *this;
}



/// @brief
/// @return
template <unsigned char Base>
BigInteger<Base> BigInteger<Base>::operator++(int) {
  BigInteger temp = *this;
  *this = *this + 1;
  return temp;
}



/// @brief
/// @return
template <unsigned char Base>
BigInteger<Base>& BigInteger<Base>::operator--() {
  *this = *this - 1;
  return *this;
}



/// @brief
/// @return
template <unsigned char Base>
BigInteger<Base> BigInteger<Base>::operator--(int) {
  BigInteger temp = *this;
  *this = *this - 1;
  return temp;
}



/// @brief
/// @param number_param1
/// @param number_param2
/// @return
template <unsigned char B>
BigInteger<B> operator+(const BigInteger<B>& number_param1, const BigInteger<B>& number_param2) {
  BigInteger<B> number_result;
  if (number_param1.sign_ == number_param2.sign_) {
    // Ambos números tienen el mismo signo
    number_result.number_ = number_param1.number_ + number_param2.number_;
    number_result.sign_ = number_param1.sign_;
  } 
  else {
    // Los números tienen signos diferentes
    if (number_param1.number_ < number_param2.number_) {
      number_result.number_ = number_param2.number_ - number_param1.number_;
      number_result.sign_ = number_param2.sign_;
    } else {
      number_result.number_ = number_param1.number_ - number_param2.number_;
      number_result.sign_ = number_param1.sign_;
    }
  }
  return number_result;
}



/// @brief
/// @param number_param
/// @return
template <unsigned char Base>
BigInteger<Base> BigInteger<Base>::operator-(const BigInteger<Base>& number_param) const {
  BigInteger number_result;
  if (sign_ == number_param.sign_) {
    if (number_ < number_param.number_) {
      number_result.number_ = number_param.number_ - number_;
      number_result.sign_ = !sign_;
    }
    else {
      number_result.number_ = number_ - number_param.number_;
      number_result.sign_ = sign_;
    }
  }
  else {
    number_result.number_ = number_ + number_param.number_;
    number_result.sign_ = sign_;
  }
  return number_result;
}



/// @brief
/// @param number_param
/// @return
template <unsigned char Base>
BigInteger<Base> BigInteger<Base>::operator*(const BigInteger<Base>& number_param) const {
  BigInteger number_result;
  number_result.number_ = number_ * number_param.number_;
  number_result.sign_ = sign_ != number_param.sign_;
  return number_result;
}



/// @brief
/// @param number_param1
/// @param number_param2
/// @return
template <unsigned char B>
BigInteger<B> operator/(const BigInteger<B>& number_param1, const BigInteger<B>& number_param2) {
  BigInteger<B> number_result;
  number_result.number_ = number_param1.number_ / number_param2.number_;
  number_result.sign_ = number_param1.sign_ != number_param2.sign_;
  return number_result;
}



/// @brief
/// @param number_param
/// @return
template <unsigned char Base>
BigInteger<Base> BigInteger<Base>::operator%(const BigInteger<Base>& number_param) const {
  BigInteger number_result;
  number_result.number_ = number_ % number_param.number_;
  number_result.sign_ = false;
  return number_result;
}



/// @brief Algoritmo RECURSIVO de Euclides para calcular el máximo común divisor
/// @param a
/// @param b
/// @return mcd
template <unsigned char Base>
BigInteger<Base> BigInteger<Base>::mcd(BigInteger<Base> a, BigInteger<Base> b) {
  // mcd(a,0) = a
  // mcd(a,b) = mcd(b,a%b)
  if (b.isZero()) {
    return a;
  }
  else {
    BigInteger resto = a % b;
    return mcd(b, resto);
  }
}



/// @brief Comprueba si el número es 0 
/// @return true si es 0, false si no lo es 
template <unsigned char Base>
bool BigInteger<Base>::isZero() {
  std::vector<unsigned char> zero_vec = {0};
  return number_.getDigitsVec() == zero_vec;
}



//---------------------------------------------------------PRACTICA 3---------------------------------------------------------



/// @brief
/// @param number_param
/// @return
template <unsigned char Base>
BigNumber<Base>* BigInteger<Base>::add(const BigNumber<Base>& number_param) const {
  const BigInteger<Base>& number = number_param.operator BigInteger<Base>();
  BigInteger<Base>* number_result = new BigInteger<Base>;
  if (sign_ == number.sign_) {
    number_result->number_ = number_ + number.number_;
    number_result->sign_ = sign_;
  }
  else {
    if (number_ < number.number_) {
      number_result->number_ = number.number_ - number_;
      number_result->sign_ = !sign_;
    }
    else {
      number_result->number_ = number_ - number.number_;
      number_result->sign_ = sign_;
    }
  }
  return number_result;
}



/// @brief
/// @param number_param
/// @return
template <unsigned char Base>
BigNumber<Base>* BigInteger<Base>::subtract(const BigNumber<Base>& number_param) const {
  const BigInteger<Base>& number = number_param.operator BigInteger<Base>();
  BigInteger<Base>* number_result = new BigInteger<Base>;
  if (sign_ == number.sign_) {
    if (number_ < number.number_) {
      number_result->number_ = number.number_ - number_;
      number_result->sign_ = !sign_;
    }
    else {
      number_result->number_ = number_ - number.number_;
      number_result->sign_ = sign_;
    }
  }
  else {
    number_result->number_ = number_ + number.number_;
    number_result->sign_ = sign_;
  }
  return number_result;
}



/// @brief
/// @param number_param
/// @return
template <unsigned char Base>
BigNumber<Base>* BigInteger<Base>::multiply(const BigNumber<Base>& number_param) const {
  const BigInteger<Base>& number = number_param.operator BigInteger<Base>();
  BigInteger<Base>* number_result = new BigInteger<Base>;
  number_result->number_ = number_ * number.number_;
  number_result->sign_ = sign_ != number.sign_;
  return number_result;
}



/// @brief
/// @param number_param
/// @return
template <unsigned char Base>
BigNumber<Base>* BigInteger<Base>::divide(const BigNumber<Base>& number_param) const {
  const BigInteger<Base>& number = number_param.operator BigInteger<Base>();
  BigInteger<Base>* number_result = new BigInteger<Base>;
  // Comprobamos si el divisor es 0
  if (number == 0) {
    throw BigNumberDivisionByZero("Error: División por cero no permitida.");
  }
  number_result->number_ = number_ / number.number_;
  number_result->sign_ = sign_ != number.sign_;
  return number_result;
}



/// @brief
/// @param os
/// @return
template <unsigned char Base>
std::ostream& BigInteger<Base>::write(std::ostream& os) const {
  if (sign_) {
    os << "-";
  }
  os << number_ << "i";
  return os;
}



/// @brief
/// @param is
/// @return
template <unsigned char Base>
std::istream& BigInteger<Base>::read(std::istream& is) {
  std::string str;
  is >> str;
  if (str[0] == '-') {
    sign_ = true;
    str = str.substr(1);
  }
  else {
    sign_ = false;
  }
  number_ = BigUnsigned<Base>((const unsigned char*)str.c_str());
  return is;
}

#endif